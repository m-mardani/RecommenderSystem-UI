export const API_BASE_URL = import.meta.env.VITE_API_URL ?? 'http://localhost:8000';
export const API_V1 = `${API_BASE_URL}/api/v1`;

export const ACCESS_TOKEN_KEY = 'ai_rec_access_token';
export const REFRESH_TOKEN_KEY = 'ai_rec_refresh_token';
export const USER_KEY = 'ai_rec_user';

export const QUERY_KEYS = {
  me: ['me'],
  users: ['users'],
  datasets: ['datasets'],
  dataset: (id: string) => ['datasets', id],
  datasetPreview: (id: string) => ['datasets', id, 'preview'],
  datasetAnalysis: (id: string) => ['datasets', id, 'analysis'],
  trainingJobs: ['training-jobs'],
  trainingJob: (id: string) => ['training-jobs', id],
  trainingProgress: (id: string) => ['training-jobs', id, 'progress'],
  models: ['models'],
  model: (id: string) => ['models', id],
  availableModels: ['models', 'available'],
  auditLogs: ['audit-logs'],
  systemSnapshot: ['system-snapshot'],
  monitoring: ['monitoring'],
  onlineUsers: ['online-users'],
} as const;

export const PAGE_SIZE_OPTIONS = [10, 25, 50, 100];
export const DEFAULT_PAGE_SIZE = 25;

export const TRAINING_STRATEGIES = [
  { value: 'collaborative_filtering', label: 'Collaborative Filtering', description: 'Learn from user-item interactions' },
  { value: 'content_based', label: 'Content-Based', description: 'Use item features for recommendations' },
  { value: 'hybrid', label: 'Hybrid', description: 'Combine collaborative and content-based' },
  { value: 'neural', label: 'Neural Network', description: 'Deep learning recommendation model' },
];
