import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatBytes(bytes: number, decimals = 2): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(decimals))} ${sizes[i]}`;
}

export function formatNumber(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return n.toString();
}

export function formatDuration(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}

export function formatDate(iso: string): string {
  return new Intl.DateTimeFormat('en-US', {
    month: 'short', day: 'numeric', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  }).format(new Date(iso));
}

export function formatRelativeTime(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  const h = Math.floor(m / 60);
  const d = Math.floor(h / 24);
  if (d > 0) return `${d}d ago`;
  if (h > 0) return `${h}h ago`;
  if (m > 0) return `${m}m ago`;
  return 'just now';
}

export function truncate(str: string, length: number): string {
  return str.length > length ? `${str.slice(0, length)}…` : str;
}

export function getStatusColor(status: string): string {
  const map: Record<string, string> = {
    READY: 'text-emerald-500', COMPLETED: 'text-emerald-500',
    RUNNING: 'text-sky-500', PROCESSING: 'text-sky-500', uploading: 'text-sky-500',
    PENDING: 'text-amber-500', pending: 'text-amber-500',
    ERROR: 'text-red-500', FAILED: 'text-red-500', error: 'text-red-500',
    CANCELLED: 'text-zinc-500',
  };
  return map[status] ?? 'text-zinc-500';
}

export function getStatusBg(status: string): string {
  const map: Record<string, string> = {
    READY: 'bg-emerald-500/10 text-emerald-500', COMPLETED: 'bg-emerald-500/10 text-emerald-500',
    RUNNING: 'bg-sky-500/10 text-sky-500', PROCESSING: 'bg-sky-500/10 text-sky-500',
    PENDING: 'bg-amber-500/10 text-amber-500',
    ERROR: 'bg-red-500/10 text-red-500', FAILED: 'bg-red-500/10 text-red-500',
    CANCELLED: 'bg-zinc-500/10 text-zinc-400',
  };
  return map[status] ?? 'bg-zinc-500/10 text-zinc-400';
}

export function sleep(ms: number) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
