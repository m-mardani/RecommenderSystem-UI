import { create } from 'zustand';
import { Notification } from '../types';

interface NotificationState {
  notifications: Notification[];
  unreadCount: number;
  addNotification: (n: Omit<Notification, 'id' | 'read' | 'created_at'>) => void;
  markRead: (id: string) => void;
  markAllRead: () => void;
  removeNotification: (id: string) => void;
  clearAll: () => void;
}

let notifId = 0;

export const useNotificationStore = create<NotificationState>((set, get) => ({
  notifications: [],
  unreadCount: 0,
  addNotification: (n) => {
    const notif: Notification = {
      ...n, id: `notif-${++notifId}`,
      read: false, created_at: new Date().toISOString(),
    };
    set((s) => ({
      notifications: [notif, ...s.notifications].slice(0, 50),
      unreadCount: s.unreadCount + 1,
    }));
  },
  markRead: (id) => {
    const { notifications } = get();
    const wasUnread = notifications.find(n => n.id === id && !n.read);
    set((s) => ({
      notifications: s.notifications.map(n => n.id === id ? { ...n, read: true } : n),
      unreadCount: Math.max(0, wasUnread ? s.unreadCount - 1 : s.unreadCount),
    }));
  },
  markAllRead: () => set((s) => ({
    notifications: s.notifications.map(n => ({ ...n, read: true })),
    unreadCount: 0,
  })),
  removeNotification: (id) => {
    const { notifications } = get();
    const wasUnread = notifications.find(n => n.id === id && !n.read);
    set((s) => ({
      notifications: s.notifications.filter(n => n.id !== id),
      unreadCount: Math.max(0, wasUnread ? s.unreadCount - 1 : s.unreadCount),
    }));
  },
  clearAll: () => set({ notifications: [], unreadCount: 0 }),
}));
