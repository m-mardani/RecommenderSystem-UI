import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation } from '@tanstack/react-query';
import { toast } from 'sonner';
import { User, Lock, Palette, Server, Check, Moon, Sun, Monitor } from 'lucide-react';
import { PageHeader } from '../../components/ui/PageHeader';
import { useAuthStore } from '../../store/authStore';
import { useThemeStore } from '../../store/themeStore';
import { API_V1 } from '../../lib/constants';
import apiClient from '../../services/api';

const profileSchema = z.object({
  full_name: z.string().min(2),
  email: z.string().email(),
});
const passwordSchema = z.object({
  current_password: z.string().min(1),
  new_password: z.string().min(8),
  confirm_password: z.string(),
}).refine(d => d.new_password === d.confirm_password, {
  message: "Passwords don't match", path: ['confirm_password'],
});

type Tab = 'profile' | 'password' | 'theme' | 'api';

export function SettingsPage() {
  const [tab, setTab] = useState<Tab>('profile');
  const { user } = useAuthStore();
  const { theme, setTheme } = useThemeStore();
  const [apiUrl, setApiUrl] = useState(API_V1);
  const [apiKey, setApiKey] = useState('sk-•••••••••••••••••••••••••••••');

  const { register: regProfile, handleSubmit: submitProfile, formState: { errors: profileErrors } } = useForm({
    resolver: zodResolver(profileSchema),
    defaultValues: { full_name: user?.full_name ?? '', email: user?.email ?? '' },
  });

  const { register: regPass, handleSubmit: submitPass, formState: { errors: passErrors }, reset: resetPass } = useForm({
    resolver: zodResolver(passwordSchema),
  });

  const profileMutation = useMutation({
    mutationFn: (data: z.infer<typeof profileSchema>) =>
      apiClient.put(`/users/${user?.id}`, data).then(r => r.data),
    onSuccess: () => toast.success('Profile updated'),
    onError: () => toast.error('Failed to update profile'),
  });

  const passwordMutation = useMutation({
    mutationFn: (data: z.infer<typeof passwordSchema>) =>
      apiClient.post('/auth/change-password', data).then(r => r.data),
    onSuccess: () => { toast.success('Password changed'); resetPass(); },
    onError: () => toast.error('Failed to change password'),
  });

  const TABS = [
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'password', label: 'Password', icon: Lock },
    { id: 'theme', label: 'Appearance', icon: Palette },
    { id: 'api', label: 'API Config', icon: Server },
  ];

  return (
    <div className="flex flex-col h-full overflow-hidden">
      <PageHeader
        title="Settings"
        breadcrumbs={[{ label: 'Dashboard', href: '/dashboard' }, { label: 'Settings' }]}
        description="Manage your profile, security, and application preferences."
      />

      <div className="flex-1 overflow-y-auto">
        <div className="p-6 max-w-3xl mx-auto space-y-5">
          {/* Tabs */}
          <div className="flex gap-1 bg-muted/30 rounded-lg p-1">
            {TABS.map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setTab(id as Tab)}
                className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-md text-sm font-medium transition-colors ${
                  tab === id ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />{label}
              </button>
            ))}
          </div>

          {/* Profile */}
          {tab === 'profile' && (
            <form onSubmit={submitProfile(d => profileMutation.mutate(d))} className="bg-card border border-border rounded-xl p-5 space-y-4">
              <h3 className="font-medium">Profile Information</h3>
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center text-2xl font-semibold text-primary">
                  {(user?.full_name || user?.username || '?').charAt(0).toUpperCase()}
                </div>
                <div>
                  <p className="font-medium">{user?.full_name || user?.username}</p>
                  <p className="text-sm text-muted-foreground">{user?.role}</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {[
                  { name: 'full_name', label: 'Full Name', errors: profileErrors },
                  { name: 'email', label: 'Email', errors: profileErrors },
                ].map(({ name, label, errors }) => (
                  <div key={name}>
                    <label className="text-xs font-medium text-muted-foreground mb-1 block">{label}</label>
                    <input
                      {...regProfile(name as 'full_name' | 'email')}
                      className="w-full h-9 px-3 rounded-md border border-border bg-input-background text-sm focus:outline-none focus:ring-1 focus:ring-ring"
                    />
                    {errors[name as keyof typeof errors]?.message && (
                      <p className="text-xs text-red-500 mt-0.5">{String(errors[name as keyof typeof errors]?.message)}</p>
                    )}
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-1 block">Username</label>
                  <input value={user?.username ?? ''} disabled className="w-full h-9 px-3 rounded-md border border-border bg-muted text-sm text-muted-foreground" />
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-1 block">Member Since</label>
                  <input value={user?.created_at ? new Date(user.created_at).toLocaleDateString() : ''} disabled className="w-full h-9 px-3 rounded-md border border-border bg-muted text-sm text-muted-foreground" />
                </div>
              </div>
              <div className="flex justify-end">
                <button type="submit" disabled={profileMutation.isPending} className="px-5 py-2 rounded-md text-sm bg-primary text-primary-foreground hover:bg-primary/90 transition-colors disabled:opacity-50">
                  {profileMutation.isPending ? 'Saving…' : 'Save Changes'}
                </button>
              </div>
            </form>
          )}

          {/* Password */}
          {tab === 'password' && (
            <form onSubmit={submitPass(d => passwordMutation.mutate(d))} className="bg-card border border-border rounded-xl p-5 space-y-4">
              <h3 className="font-medium">Change Password</h3>
              {[
                { name: 'current_password', label: 'Current Password' },
                { name: 'new_password', label: 'New Password' },
                { name: 'confirm_password', label: 'Confirm New Password' },
              ].map(({ name, label }) => (
                <div key={name}>
                  <label className="text-xs font-medium text-muted-foreground mb-1 block">{label}</label>
                  <input
                    {...regPass(name as 'current_password' | 'new_password' | 'confirm_password')}
                    type="password"
                    placeholder="••••••••"
                    className="w-full h-9 px-3 rounded-md border border-border bg-input-background text-sm focus:outline-none focus:ring-1 focus:ring-ring"
                  />
                  {passErrors[name as keyof typeof passErrors]?.message && (
                    <p className="text-xs text-red-500 mt-0.5">{String(passErrors[name as keyof typeof passErrors]?.message)}</p>
                  )}
                </div>
              ))}
              <div className="flex justify-end">
                <button type="submit" disabled={passwordMutation.isPending} className="px-5 py-2 rounded-md text-sm bg-primary text-primary-foreground hover:bg-primary/90 transition-colors disabled:opacity-50">
                  {passwordMutation.isPending ? 'Saving…' : 'Update Password'}
                </button>
              </div>
            </form>
          )}

          {/* Theme */}
          {tab === 'theme' && (
            <div className="bg-card border border-border rounded-xl p-5 space-y-5">
              <h3 className="font-medium">Appearance</h3>
              <div>
                <p className="text-sm font-medium mb-3">Theme</p>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { id: 'light', label: 'Light', icon: Sun },
                    { id: 'dark', label: 'Dark', icon: Moon },
                    { id: 'system', label: 'System', icon: Monitor },
                  ].map(({ id, label, icon: Icon }) => (
                    <button
                      key={id}
                      onClick={() => setTheme(id as 'light' | 'dark' | 'system')}
                      className={`flex flex-col items-center gap-2 p-4 rounded-xl border transition-colors ${
                        theme === id ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/50'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                      <span className="text-sm">{label}</span>
                      {theme === id && <Check className="w-3.5 h-3.5 text-primary" />}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* API Config */}
          {tab === 'api' && (
            <div className="bg-card border border-border rounded-xl p-5 space-y-4">
              <h3 className="font-medium">API Configuration</h3>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1.5 block">API Base URL</label>
                <input
                  value={apiUrl}
                  onChange={e => setApiUrl(e.target.value)}
                  className="w-full h-9 px-3 rounded-md border border-border bg-input-background text-sm font-mono focus:outline-none focus:ring-1 focus:ring-ring"
                />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1.5 block">API Key</label>
                <input
                  value={apiKey}
                  onChange={e => setApiKey(e.target.value)}
                  type="password"
                  className="w-full h-9 px-3 rounded-md border border-border bg-input-background text-sm font-mono focus:outline-none focus:ring-1 focus:ring-ring"
                />
                <p className="text-xs text-muted-foreground mt-1">Replace with your actual API key from the platform</p>
              </div>
              <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg">
                <p className="text-xs text-amber-600 dark:text-amber-400">
                  Keep your API key secret. Never share it in public repositories or client-side code.
                </p>
              </div>
              <div className="flex justify-end">
                <button
                  onClick={() => toast.success('API configuration saved')}
                  className="px-5 py-2 rounded-md text-sm bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
                >
                  Save Configuration
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
