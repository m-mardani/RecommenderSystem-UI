import { useQuery } from '@tanstack/react-query';
import {
  Cpu, HardDrive, MemoryStick, Activity, RefreshCw, Loader2,
  Upload, List
} from 'lucide-react';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from 'recharts';
import { PageHeader } from '../../components/ui/PageHeader';
import { StatusBadge } from '../../components/ui/StatusBadge';
import { LogViewer } from '../../components/ui/LogViewer';
import { ProgressCard } from '../../components/ui/ProgressCard';
import { QUERY_KEYS } from '../../lib/constants';
import { monitoringService } from '../../services/monitoringService';
import { formatRelativeTime } from '../../lib/utils';
import { useState } from 'react';

const CHART_TOOLTIP_STYLE = {
  contentStyle: { background: 'var(--card)', border: '1px solid var(--border)', borderRadius: '8px', fontSize: '12px' },
};

// Mock historical metrics
const MOCK_METRICS = Array.from({ length: 20 }, (_, i) => ({
  time: `${19 - i}m`,
  cpu: 20 + Math.random() * 40,
  memory: 45 + Math.random() * 20,
})).reverse();

type Tab = 'overview' | 'jobs' | 'uploads' | 'logs';

export function MonitoringPage() {
  const [tab, setTab] = useState<Tab>('overview');
  const [refreshKey, setRefreshKey] = useState(0);

  const { data: snapshot, isLoading: snapshotLoading } = useQuery({
    queryKey: [...QUERY_KEYS.systemSnapshot, refreshKey],
    queryFn: monitoringService.snapshot,
    refetchInterval: 30_000,
  });

  const { data: jobs, isLoading: jobsLoading } = useQuery({
    queryKey: [...QUERY_KEYS.monitoring, 'jobs', refreshKey],
    queryFn: monitoringService.runningJobs,
    enabled: tab === 'jobs',
    refetchInterval: 10_000,
  });

  const { data: uploads } = useQuery({
    queryKey: [...QUERY_KEYS.monitoring, 'uploads', refreshKey],
    queryFn: monitoringService.uploads,
    enabled: tab === 'uploads',
    refetchInterval: 5_000,
  });

  const { data: logs } = useQuery({
    queryKey: [...QUERY_KEYS.monitoring, 'logs', refreshKey],
    queryFn: () => monitoringService.logs(200),
    enabled: tab === 'logs',
    refetchInterval: 10_000,
  });

  const { data: queue } = useQuery({
    queryKey: [...QUERY_KEYS.monitoring, 'queue'],
    queryFn: monitoringService.queue,
    refetchInterval: 10_000,
  });

  const metrics = snapshot?.metrics;

  return (
    <div className="flex flex-col h-full overflow-hidden">
      <PageHeader
        title="Monitoring"
        breadcrumbs={[{ label: 'Dashboard', href: '/dashboard' }, { label: 'Monitoring' }]}
        description="Real-time system health, job monitoring, and operational logs."
        actions={
          <button
            onClick={() => setRefreshKey(k => k + 1)}
            className="flex items-center gap-1.5 h-8 px-3 rounded-md text-sm border border-border hover:bg-muted transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" /> Refresh
          </button>
        }
      />

      <div className="flex-1 overflow-y-auto">
        <div className="p-6 space-y-5">
          {/* System overview cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { label: 'CPU Usage', value: metrics?.cpu_percent ?? 34, icon: Cpu, color: 'text-sky-500' },
              { label: 'Memory', value: metrics?.memory_percent ?? 58, icon: MemoryStick, color: 'text-violet-500' },
              { label: 'Disk', value: metrics?.disk_percent ?? 42, icon: HardDrive, color: 'text-amber-500' },
              { label: 'Active Jobs', value: snapshot?.active_jobs ?? 3, icon: Activity, color: 'text-emerald-500', isCount: true },
            ].map(({ label, value, icon: Icon, color, isCount }) => (
              <div key={label} className="bg-card border border-border rounded-xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm text-muted-foreground">{label}</span>
                  <Icon className={`w-4 h-4 ${color}`} />
                </div>
                {isCount ? (
                  <p className="text-2xl font-semibold">{value}</p>
                ) : (
                  <>
                    <p className="text-2xl font-semibold">{Math.round(value as number)}%</p>
                    <div className="mt-2 h-1.5 bg-muted rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full ${color.replace('text-', 'bg-')} transition-all`}
                        style={{ width: `${value}%` }}
                      />
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>

          {/* Queue status */}
          {queue && (
            <div className="grid grid-cols-4 gap-3">
              {[
                { label: 'Pending', value: queue.pending, color: 'text-amber-500' },
                { label: 'Running', value: queue.running, color: 'text-sky-500' },
                { label: 'Completed Today', value: queue.completed_today, color: 'text-emerald-500' },
                { label: 'Failed Today', value: queue.failed_today, color: 'text-red-500' },
              ].map(({ label, value, color }) => (
                <div key={label} className="bg-card border border-border rounded-lg p-3">
                  <p className="text-xs text-muted-foreground">{label}</p>
                  <p className={`text-xl font-semibold mt-1 ${color}`}>{value}</p>
                </div>
              ))}
            </div>
          )}

          {/* Tabs */}
          <div className="flex gap-1 border-b border-border">
            {[
              { id: 'overview', label: 'Metrics', icon: Activity },
              { id: 'jobs', label: 'Running Jobs', icon: Cpu },
              { id: 'uploads', label: 'Uploads', icon: Upload },
              { id: 'logs', label: 'System Logs', icon: List },
            ].map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setTab(id as Tab)}
                className={`flex items-center gap-2 px-4 py-2.5 text-sm border-b-2 transition-colors ${
                  tab === id ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />{label}
              </button>
            ))}
          </div>

          {/* Overview: metrics chart */}
          {tab === 'overview' && (
            <div className="bg-card border border-border rounded-xl p-4">
              <h3 className="text-sm font-medium mb-4">CPU & Memory (Last 20 min)</h3>
              <ResponsiveContainer width="100%" height={220}>
                <AreaChart data={MOCK_METRICS} margin={{ top: 0, right: 0, bottom: 0, left: -20 }}>
                  <defs>
                    <linearGradient id="gradCpu" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#38bdf8" stopOpacity={0.2} />
                      <stop offset="95%" stopColor="#38bdf8" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="gradMem" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#a78bfa" stopOpacity={0.2} />
                      <stop offset="95%" stopColor="#a78bfa" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="time" tick={{ fontSize: 10, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                  <YAxis domain={[0, 100]} tick={{ fontSize: 10, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} tickFormatter={v => `${v}%`} />
                  <Tooltip {...CHART_TOOLTIP_STYLE} formatter={(v: number) => [`${v.toFixed(1)}%`]} />
                  <Area type="monotone" dataKey="cpu" stroke="#38bdf8" fill="url(#gradCpu)" strokeWidth={2} name="CPU" />
                  <Area type="monotone" dataKey="memory" stroke="#a78bfa" fill="url(#gradMem)" strokeWidth={2} name="Memory" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          )}

          {/* Running jobs */}
          {tab === 'jobs' && (
            <div className="bg-card border border-border rounded-xl overflow-hidden">
              {jobsLoading ? (
                <div className="flex items-center justify-center py-12"><Loader2 className="w-5 h-5 animate-spin text-muted-foreground" /></div>
              ) : jobs && jobs.length > 0 ? (
                <div className="divide-y divide-border/50">
                  {jobs.map(job => (
                    <div key={job.id} className="px-5 py-4 space-y-2">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium">{job.name}</p>
                          <p className="text-xs text-muted-foreground">{job.dataset_name} · epoch {job.current_epoch}/{job.total_epochs}</p>
                        </div>
                        <StatusBadge status={job.status} size="sm" />
                      </div>
                      <ProgressCard label="" value={job.progress} color="blue" size="sm" eta={job.eta_seconds} />
                    </div>
                  ))}
                </div>
              ) : (
                <div className="py-12 text-center text-sm text-muted-foreground">No active jobs</div>
              )}
            </div>
          )}

          {/* Uploads */}
          {tab === 'uploads' && (
            <div className="bg-card border border-border rounded-xl overflow-hidden">
              {uploads && uploads.length > 0 ? (
                <div className="divide-y divide-border/50">
                  {uploads.map(u => (
                    <div key={u.id} className="px-5 py-3 space-y-1.5">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-medium">{u.filename}</p>
                        <StatusBadge status={u.status} size="sm" />
                      </div>
                      <ProgressCard label="" value={u.progress} color="blue" size="sm" />
                      <p className="text-xs text-muted-foreground">{u.size_mb.toFixed(1)} MB · {formatRelativeTime(u.started_at)}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="py-12 text-center text-sm text-muted-foreground">No active uploads</div>
              )}
            </div>
          )}

          {/* Logs */}
          {tab === 'logs' && (
            <LogViewer logs={logs ?? []} maxHeight="500px" autoScroll={false} />
          )}
        </div>
      </div>
    </div>
  );
}
