import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router';
import { toast } from 'sonner';
import { Plus, Cpu, XCircle } from 'lucide-react';
import { PageHeader } from '../../components/ui/PageHeader';
import { DataTable, Column } from '../../components/ui/DataTable';
import { StatusBadge } from '../../components/ui/StatusBadge';
import { Pagination } from '../../components/ui/Pagination';
import { SearchBox } from '../../components/ui/SearchBox';
import { ConfirmationDialog } from '../../components/ui/ConfirmationDialog';
import { ProgressCard } from '../../components/ui/ProgressCard';
import { TrainingWizard } from './TrainingWizard';
import { QUERY_KEYS, DEFAULT_PAGE_SIZE } from '../../lib/constants';
import { trainingService } from '../../services/trainingService';
import { TrainingJob } from '../../types';
import { formatRelativeTime, formatDuration } from '../../lib/utils';

export function TrainingPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [wizardOpen, setWizardOpen] = useState(false);
  const [cancelTarget, setCancelTarget] = useState<TrainingJob | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: [...QUERY_KEYS.trainingJobs, page, search, statusFilter],
    queryFn: () => trainingService.list({ page, page_size: DEFAULT_PAGE_SIZE, status: statusFilter || undefined }),
    refetchInterval: 10_000,
    placeholderData: prev => prev,
  });

  const cancelMutation = useMutation({
    mutationFn: (id: string) => trainingService.cancel(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.trainingJobs });
      toast.success('Job cancelled');
      setCancelTarget(null);
    },
    onError: () => toast.error('Failed to cancel job'),
  });

  const columns: Column<TrainingJob>[] = [
    {
      key: 'name', header: 'Job Name', sortable: true,
      render: (row) => (
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded bg-violet-500/10 flex items-center justify-center shrink-0">
            <Cpu className="w-3.5 h-3.5 text-violet-500" />
          </div>
          <div>
            <p className="font-medium text-sm">{row.name}</p>
            <p className="text-xs text-muted-foreground">{row.dataset_name} · {row.config.strategy}</p>
          </div>
        </div>
      ),
    },
    {
      key: 'status', header: 'Status',
      render: (row) => <StatusBadge status={row.status} size="sm" />,
    },
    {
      key: 'progress', header: 'Progress',
      render: (row) => row.status === 'RUNNING' ? (
        <ProgressCard
          label=""
          value={row.progress}
          color="blue"
          size="sm"
          className="w-32"
          eta={row.eta_seconds}
        />
      ) : (
        <span className="text-xs text-muted-foreground">
          {row.current_epoch}/{row.total_epochs} epochs
        </span>
      ),
    },
    {
      key: 'current_loss', header: 'Loss',
      render: (row) => (
        <span className="font-mono text-xs text-muted-foreground">
          {row.current_loss != null ? row.current_loss.toFixed(4) : '—'}
        </span>
      ),
    },
    {
      key: 'created_at', header: 'Created', sortable: true,
      render: (row) => <span className="text-xs text-muted-foreground">{formatRelativeTime(row.created_at)}</span>,
    },
    {
      key: 'actions', header: '',
      render: (row) => (
        <div className="flex items-center gap-1" onClick={e => e.stopPropagation()}>
          {row.status === 'RUNNING' && (
            <button
              onClick={() => setCancelTarget(row)}
              className="p-1.5 rounded hover:bg-red-500/10 hover:text-red-500 transition-colors" title="Cancel"
            >
              <XCircle className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      ),
    },
  ];

  const statusOptions = ['', 'RUNNING', 'PENDING', 'COMPLETED', 'FAILED', 'CANCELLED'];

  return (
    <div className="flex flex-col h-full overflow-hidden">
      <PageHeader
        title="Training"
        breadcrumbs={[{ label: 'Dashboard', href: '/dashboard' }, { label: 'Training' }]}
        description="Manage your model training jobs. Launch new jobs, monitor progress, and review history."
        actions={
          <button
            onClick={() => setWizardOpen(true)}
            className="flex items-center gap-1.5 h-8 px-3 rounded-md text-sm bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" /> New Training Job
          </button>
        }
      />

      <div className="flex-1 overflow-y-auto">
        <div className="p-6 space-y-4">
          <div className="flex items-center gap-3 flex-wrap">
            <SearchBox value={search} onChange={v => { setSearch(v); setPage(1); }} placeholder="Search jobs…" className="w-56" />
            <div className="flex items-center gap-1">
              {statusOptions.map(s => (
                <button
                  key={s}
                  onClick={() => setStatusFilter(s)}
                  className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                    statusFilter === s ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:bg-muted'
                  }`}
                >
                  {s || 'All'}
                </button>
              ))}
            </div>
            {data && (
              <span className="text-xs text-muted-foreground ml-auto">{data.total} job{data.total !== 1 ? 's' : ''}</span>
            )}
          </div>

          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <DataTable
              columns={columns}
              data={data?.items ?? []}
              loading={isLoading}
              rowKey={r => r.id}
              onRowClick={r => navigate(`/training/${r.id}`)}
              emptyMessage="No training jobs"
              emptyDescription="Launch your first training job to get started"
              emptyIcon={<Cpu className="w-6 h-6 text-muted-foreground" />}
            />
            {data && data.pages > 1 && (
              <Pagination page={data.page} pages={data.pages} total={data.total} pageSize={DEFAULT_PAGE_SIZE} onPageChange={setPage} />
            )}
          </div>
        </div>
      </div>

      {wizardOpen && <TrainingWizard onClose={() => setWizardOpen(false)} />}

      <ConfirmationDialog
        open={!!cancelTarget}
        onClose={() => setCancelTarget(null)}
        onConfirm={() => cancelTarget && cancelMutation.mutate(cancelTarget.id)}
        title="Cancel Training Job"
        description={`Cancel "${cancelTarget?.name}"? The job will be stopped and cannot be resumed.`}
        confirmLabel="Cancel Job"
        danger
        loading={cancelMutation.isPending}
      />
    </div>
  );
}
