import { useState } from 'react';
import { useParams, useNavigate } from 'react-router';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { ArrowLeft, Cpu, XCircle, Loader2 } from 'lucide-react';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from 'recharts';
import { PageHeader } from '../../components/ui/PageHeader';
import { StatusBadge } from '../../components/ui/StatusBadge';
import { ProgressCard } from '../../components/ui/ProgressCard';
import { LogViewer } from '../../components/ui/LogViewer';
import { ConfirmationDialog } from '../../components/ui/ConfirmationDialog';
import { QUERY_KEYS } from '../../lib/constants';
import { trainingService } from '../../services/trainingService';
import { formatRelativeTime, formatDuration } from '../../lib/utils';

const CHART_TOOLTIP_STYLE = {
  contentStyle: {
    background: 'var(--card)', border: '1px solid var(--border)',
    borderRadius: '8px', fontSize: '12px', color: 'var(--foreground)',
  },
};

export function TrainingDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [cancelOpen, setCancelOpen] = useState(false);

  const { data: job } = useQuery({
    queryKey: QUERY_KEYS.trainingJob(id!),
    queryFn: () => trainingService.get(id!),
    enabled: !!id,
    refetchInterval: (q) => {
      const status = q.state.data?.status;
      return status === 'RUNNING' || status === 'PENDING' ? 5_000 : false;
    },
  });

  const { data: progress } = useQuery({
    queryKey: QUERY_KEYS.trainingProgress(id!),
    queryFn: () => trainingService.getProgress(id!),
    enabled: !!id && (job?.status === 'RUNNING' || job?.status === 'PENDING'),
    refetchInterval: 3_000,
  });

  const { data: logs } = useQuery({
    queryKey: [...QUERY_KEYS.trainingProgress(id!), 'logs'],
    queryFn: () => trainingService.getLogs(id!),
    enabled: !!id,
    refetchInterval: (q) => {
      return job?.status === 'RUNNING' ? 5_000 : false;
    },
  });

  const { data: epochs } = useQuery({
    queryKey: [...QUERY_KEYS.trainingJob(id!), 'epochs'],
    queryFn: () => trainingService.getEpochMetrics(id!),
    enabled: !!id,
  });

  const cancelMutation = useMutation({
    mutationFn: () => trainingService.cancel(id!),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.trainingJob(id!) });
      toast.success('Job cancelled');
      setCancelOpen(false);
    },
    onError: () => toast.error('Failed to cancel job'),
  });

  if (!job) return (
    <div className="flex items-center justify-center h-full">
      <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
    </div>
  );

  const isActive = job.status === 'RUNNING' || job.status === 'PENDING';
  const currentProgress = progress ?? job;

  return (
    <div className="flex flex-col h-full overflow-hidden">
      <PageHeader
        breadcrumbs={[
          { label: 'Dashboard', href: '/dashboard' },
          { label: 'Training', href: '/training' },
          { label: job.name },
        ]}
        actions={
          isActive ? (
            <button
              onClick={() => setCancelOpen(true)}
              className="flex items-center gap-1.5 h-8 px-3 rounded-md text-sm bg-red-500/10 text-red-500 hover:bg-red-500/20 border border-red-500/20 transition-colors"
            >
              <XCircle className="w-3.5 h-3.5" /> Cancel Job
            </button>
          ) : undefined
        }
      />

      <div className="flex-1 overflow-y-auto">
        <div className="p-6 space-y-5">
          {/* Header */}
          <div className="flex items-start gap-3">
            <button onClick={() => navigate('/training')} className="p-1.5 rounded hover:bg-muted transition-colors mt-0.5">
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div className="w-10 h-10 rounded-lg bg-violet-500/10 flex items-center justify-center">
              <Cpu className="w-5 h-5 text-violet-500" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-3">
                <h1 className="font-semibold">{job.name}</h1>
                <StatusBadge status={job.status} />
              </div>
              <p className="text-sm text-muted-foreground">{job.dataset_name} · {job.config.strategy} · {formatRelativeTime(job.created_at)}</p>
            </div>
          </div>

          {/* Progress (if running) */}
          {isActive && (
            <div className="bg-card border border-border rounded-xl p-4 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Training Progress</span>
                <span className="text-xs font-mono text-muted-foreground">
                  Epoch {currentProgress.current_epoch}/{currentProgress.total_epochs}
                </span>
              </div>
              <ProgressCard label="Overall" value={currentProgress.progress} color="blue" eta={currentProgress.eta_seconds} />
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <p className="text-xs text-muted-foreground">Current Loss</p>
                  <p className="text-sm font-mono font-medium">{currentProgress.current_loss?.toFixed(4) ?? '—'}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Best Loss</p>
                  <p className="text-sm font-mono font-medium">{currentProgress.best_loss?.toFixed(4) ?? '—'}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">ETA</p>
                  <p className="text-sm font-medium">{currentProgress.eta_seconds ? formatDuration(currentProgress.eta_seconds) : '—'}</p>
                </div>
              </div>
            </div>
          )}

          {/* Config */}
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-card border border-border rounded-xl p-4">
              <h3 className="text-sm font-medium mb-3">Configuration</h3>
              <div className="space-y-2">
                {[
                  ['Strategy', job.config.strategy],
                  ['Epochs', job.config.epochs],
                  ['Learning Rate', job.config.learning_rate],
                  ['Batch Size', job.config.batch_size],
                  ['Auto Config', job.config.auto_configure ? 'Yes' : 'No'],
                ].map(([label, value]) => (
                  <div key={String(label)} className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">{label}</span>
                    <span className="text-xs font-mono font-medium">{String(value)}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="bg-card border border-border rounded-xl p-4">
              <h3 className="text-sm font-medium mb-3">Timeline</h3>
              <div className="space-y-2">
                {[
                  ['Created', formatRelativeTime(job.created_at)],
                  ['Started', job.started_at ? formatRelativeTime(job.started_at) : '—'],
                  ['Completed', job.completed_at ? formatRelativeTime(job.completed_at) : '—'],
                  ['Model ID', job.model_id ?? '—'],
                ].map(([label, value]) => (
                  <div key={String(label)} className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">{label}</span>
                    <span className="text-xs font-medium">{String(value)}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Epoch chart */}
          {epochs && epochs.length > 0 && (
            <div className="bg-card border border-border rounded-xl p-4">
              <h3 className="text-sm font-medium mb-4">Training Loss</h3>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={epochs} margin={{ top: 0, right: 0, bottom: 0, left: -20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="epoch" tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                  <Tooltip {...CHART_TOOLTIP_STYLE} />
                  <Legend wrapperStyle={{ fontSize: '11px' }} />
                  <Line type="monotone" dataKey="loss" stroke="#38bdf8" dot={false} strokeWidth={2} name="Train Loss" />
                  <Line type="monotone" dataKey="val_loss" stroke="#a78bfa" dot={false} strokeWidth={2} name="Val Loss" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}

          {/* Logs */}
          <div>
            <h3 className="text-sm font-medium mb-3">Logs</h3>
            <LogViewer logs={logs ?? []} maxHeight="280px" autoScroll={isActive} />
          </div>
        </div>
      </div>

      <ConfirmationDialog
        open={cancelOpen}
        onClose={() => setCancelOpen(false)}
        onConfirm={() => cancelMutation.mutate()}
        title="Cancel Training Job"
        description={`Cancel "${job.name}"? Progress will be lost.`}
        confirmLabel="Cancel Job"
        danger
        loading={cancelMutation.isPending}
      />
    </div>
  );
}
