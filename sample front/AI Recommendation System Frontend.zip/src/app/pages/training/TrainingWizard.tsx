import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner';
import { X, ChevronRight, ChevronLeft, Check, Zap, Settings2, Database, Play, Loader2 } from 'lucide-react';
import { QUERY_KEYS, TRAINING_STRATEGIES } from '../../lib/constants';
import { datasetService } from '../../services/datasetService';
import { trainingService } from '../../services/trainingService';
import { TrainingConfig, TrainingStrategy } from '../../types';

const STEPS = [
  { id: 'dataset', label: 'Select Dataset', icon: Database },
  { id: 'strategy', label: 'Strategy', icon: Zap },
  { id: 'config', label: 'Configure', icon: Settings2 },
  { id: 'review', label: 'Review & Launch', icon: Play },
];

interface Props { onClose: () => void; }

export function TrainingWizard({ onClose }: Props) {
  const queryClient = useQueryClient();
  const [step, setStep] = useState(0);
  const [jobName, setJobName] = useState('');
  const [datasetId, setDatasetId] = useState('');
  const [strategy, setStrategy] = useState<TrainingStrategy>('collaborative_filtering');
  const [autoConfig, setAutoConfig] = useState(true);
  const [config, setConfig] = useState<Partial<TrainingConfig>>({
    epochs: 50, learning_rate: 0.001, batch_size: 256,
    user_column: 'user_id', item_column: 'item_id', rating_column: 'rating',
  });

  const { data: datasetsData } = useQuery({
    queryKey: QUERY_KEYS.datasets,
    queryFn: () => datasetService.list({ page_size: 100 }),
  });

  const createMutation = useMutation({
    mutationFn: () => {
      if (autoConfig) {
        return trainingService.autoCreate(datasetId, jobName);
      }
      return trainingService.create({
        name: jobName,
        dataset_id: datasetId,
        config: {
          strategy,
          auto_configure: false,
          epochs: config.epochs ?? 50,
          learning_rate: config.learning_rate ?? 0.001,
          batch_size: config.batch_size ?? 256,
          user_column: config.user_column,
          item_column: config.item_column,
          rating_column: config.rating_column,
        },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.trainingJobs });
      toast.success('Training job launched successfully!');
      onClose();
    },
    onError: () => toast.error('Failed to launch training job'),
  });

  const datasets = datasetsData?.items.filter(d => d.status === 'READY') ?? [];
  const selectedDataset = datasets.find(d => d.id === datasetId);
  const selectedStrategy = TRAINING_STRATEGIES.find(s => s.value === strategy);

  const canNext = [
    datasetId !== '' && jobName !== '',
    true,
    true,
    true,
  ][step];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 16 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 16 }}
        onClick={e => e.stopPropagation()}
        className="bg-card border border-border rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-border">
          <h2 className="font-semibold">New Training Job</h2>
          <button onClick={onClose} className="p-1 rounded hover:bg-muted transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Steps */}
        <div className="flex items-center px-6 py-3 bg-muted/20 border-b border-border gap-1">
          {STEPS.map((s, i) => (
            <div key={s.id} className="flex items-center gap-1">
              <button
                onClick={() => i < step && setStep(i)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
                  i === step ? 'bg-primary text-primary-foreground'
                  : i < step ? 'text-emerald-500 hover:bg-muted'
                  : 'text-muted-foreground'
                }`}
              >
                {i < step ? <Check className="w-3 h-3" /> : <s.icon className="w-3 h-3" />}
                <span className="hidden sm:block">{s.label}</span>
              </button>
              {i < STEPS.length - 1 && <ChevronRight className="w-3 h-3 text-muted-foreground" />}
            </div>
          ))}
        </div>

        {/* Content */}
        <div className="p-6 min-h-[320px]">
          <AnimatePresence mode="wait">
            <motion.div
              key={step}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.15 }}
            >
              {/* Step 0: Dataset + Name */}
              {step === 0 && (
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium mb-1.5 block">Job Name *</label>
                    <input
                      value={jobName}
                      onChange={e => setJobName(e.target.value)}
                      placeholder="e.g. Movie Recommender v2"
                      className="w-full h-9 px-3 rounded-md border border-border bg-input-background text-sm focus:outline-none focus:ring-1 focus:ring-ring"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-1.5 block">Select Dataset *</label>
                    <div className="space-y-2 max-h-48 overflow-y-auto">
                      {datasets.length === 0 ? (
                        <p className="text-sm text-muted-foreground py-4 text-center">No ready datasets found</p>
                      ) : (
                        datasets.map(d => (
                          <label key={d.id} className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${
                            datasetId === d.id ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/50'
                          }`}>
                            <input type="radio" name="dataset" value={d.id} checked={datasetId === d.id}
                              onChange={() => setDatasetId(d.id)} className="accent-primary" />
                            <div>
                              <p className="text-sm font-medium">{d.name}</p>
                              <p className="text-xs text-muted-foreground">
                                {d.row_count?.toLocaleString()} rows · {d.column_count} cols
                              </p>
                            </div>
                          </label>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* Step 1: Strategy */}
              {step === 1 && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-sm font-medium">Training Strategy</label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input type="checkbox" checked={autoConfig} onChange={e => setAutoConfig(e.target.checked)} className="accent-primary" />
                      <span className="text-xs text-muted-foreground">Auto-configure</span>
                    </label>
                  </div>
                  {TRAINING_STRATEGIES.map(s => (
                    <label key={s.value} className={`flex items-start gap-3 p-4 rounded-lg border cursor-pointer transition-colors ${
                      strategy === s.value ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/50'
                    }`}>
                      <input type="radio" name="strategy" value={s.value} checked={strategy === s.value}
                        onChange={() => setStrategy(s.value as TrainingStrategy)} className="accent-primary mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">{s.label}</p>
                        <p className="text-xs text-muted-foreground">{s.description}</p>
                      </div>
                    </label>
                  ))}
                </div>
              )}

              {/* Step 2: Configure */}
              {step === 2 && (
                <div className="space-y-4">
                  {autoConfig ? (
                    <div className="flex items-center gap-3 p-4 bg-emerald-500/10 rounded-lg border border-emerald-500/20">
                      <Zap className="w-5 h-5 text-emerald-500" />
                      <div>
                        <p className="text-sm font-medium text-emerald-500">Auto-Configure Enabled</p>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          Optimal hyperparameters will be automatically selected based on your dataset.
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 gap-4">
                      {[
                        { key: 'epochs', label: 'Epochs', type: 'number', min: 1 },
                        { key: 'learning_rate', label: 'Learning Rate', type: 'number', step: 0.0001 },
                        { key: 'batch_size', label: 'Batch Size', type: 'number', min: 16 },
                      ].map(({ key, label, type, min, step: inputStep }) => (
                        <div key={key}>
                          <label className="text-xs font-medium text-muted-foreground mb-1 block">{label}</label>
                          <input
                            type={type}
                            min={min}
                            step={inputStep}
                            value={config[key as keyof typeof config] as number}
                            onChange={e => setConfig(prev => ({ ...prev, [key]: parseFloat(e.target.value) }))}
                            className="w-full h-9 px-3 rounded-md border border-border bg-input-background text-sm focus:outline-none focus:ring-1 focus:ring-ring"
                          />
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="space-y-3 mt-4">
                    <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Column Mapping</p>
                    {[
                      { key: 'user_column', label: 'User Column', placeholder: 'user_id' },
                      { key: 'item_column', label: 'Item Column', placeholder: 'item_id' },
                      { key: 'rating_column', label: 'Rating Column', placeholder: 'rating' },
                    ].map(({ key, label, placeholder }) => (
                      <div key={key} className="grid grid-cols-2 gap-3 items-center">
                        <label className="text-sm text-muted-foreground">{label}</label>
                        <input
                          value={config[key as keyof typeof config] as string ?? ''}
                          onChange={e => setConfig(prev => ({ ...prev, [key]: e.target.value }))}
                          placeholder={placeholder}
                          className="h-8 px-2.5 rounded-md border border-border bg-input-background text-sm focus:outline-none focus:ring-1 focus:ring-ring"
                        />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Step 3: Review */}
              {step === 3 && (
                <div className="space-y-4">
                  <p className="text-sm text-muted-foreground">Review your training configuration before launching.</p>
                  <div className="bg-muted/30 rounded-lg border border-border overflow-hidden">
                    {[
                      ['Job Name', jobName],
                      ['Dataset', selectedDataset?.name ?? datasetId],
                      ['Strategy', selectedStrategy?.label ?? strategy],
                      ['Configuration', autoConfig ? 'Auto (recommended)' : 'Manual'],
                      ...(!autoConfig ? [
                        ['Epochs', String(config.epochs)],
                        ['Learning Rate', String(config.learning_rate)],
                        ['Batch Size', String(config.batch_size)],
                      ] : []),
                      ['User Column', config.user_column || 'user_id'],
                      ['Item Column', config.item_column || 'item_id'],
                      ['Rating Column', config.rating_column || 'rating'],
                    ].map(([label, value]) => (
                      <div key={label} className="flex items-center justify-between px-4 py-2.5 border-b border-border last:border-0">
                        <span className="text-xs text-muted-foreground">{label}</span>
                        <span className="text-xs font-medium">{value}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-border">
          <button
            onClick={() => step === 0 ? onClose() : setStep(s => s - 1)}
            className="flex items-center gap-1.5 px-4 py-2 rounded-md text-sm border border-border hover:bg-muted transition-colors"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
            {step === 0 ? 'Cancel' : 'Back'}
          </button>
          {step < STEPS.length - 1 ? (
            <button
              onClick={() => setStep(s => s + 1)}
              disabled={!canNext}
              className="flex items-center gap-1.5 px-4 py-2 rounded-md text-sm bg-primary text-primary-foreground hover:bg-primary/90 transition-colors disabled:opacity-50"
            >
              Next <ChevronRight className="w-3.5 h-3.5" />
            </button>
          ) : (
            <button
              onClick={() => createMutation.mutate()}
              disabled={createMutation.isPending}
              className="flex items-center gap-1.5 px-5 py-2 rounded-md text-sm bg-emerald-500 text-white hover:bg-emerald-600 transition-colors disabled:opacity-50"
            >
              {createMutation.isPending ? (
                <><Loader2 className="w-3.5 h-3.5 animate-spin" /> Launching…</>
              ) : (
                <><Play className="w-3.5 h-3.5" /> Launch Training</>
              )}
            </button>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}
