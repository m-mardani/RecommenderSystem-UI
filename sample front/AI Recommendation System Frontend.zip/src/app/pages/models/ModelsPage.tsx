import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router';
import { toast } from 'sonner';
import { BrainCircuit, Trash2, Eye, Star, Filter } from 'lucide-react';
import { PageHeader } from '../../components/ui/PageHeader';
import { DataTable, Column } from '../../components/ui/DataTable';
import { StatusBadge } from '../../components/ui/StatusBadge';
import { Pagination } from '../../components/ui/Pagination';
import { SearchBox } from '../../components/ui/SearchBox';
import { ConfirmationDialog } from '../../components/ui/ConfirmationDialog';
import { QUERY_KEYS, DEFAULT_PAGE_SIZE, TRAINING_STRATEGIES } from '../../lib/constants';
import { modelService } from '../../services/modelService';
import { Model } from '../../types';
import { formatRelativeTime } from '../../lib/utils';

export function ModelsPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [strategy, setStrategy] = useState('');
  const [deleteTarget, setDeleteTarget] = useState<Model | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: [...QUERY_KEYS.models, page, search, strategy],
    queryFn: () => modelService.list({ page, page_size: DEFAULT_PAGE_SIZE, search, strategy: strategy || undefined }),
    placeholderData: prev => prev,
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => modelService.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.models });
      toast.success('Model deleted');
      setDeleteTarget(null);
    },
    onError: () => toast.error('Failed to delete model'),
  });

  const columns: Column<Model>[] = [
    {
      key: 'name', header: 'Model', sortable: true,
      render: (row) => (
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded bg-violet-500/10 flex items-center justify-center shrink-0">
            <BrainCircuit className="w-3.5 h-3.5 text-violet-500" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <p className="font-medium text-sm">{row.name}</p>
              {row.is_active && <Star className="w-3 h-3 text-amber-400 fill-amber-400" />}
            </div>
            <p className="text-xs text-muted-foreground">v{row.version} · {row.dataset_name}</p>
          </div>
        </div>
      ),
    },
    {
      key: 'strategy', header: 'Strategy',
      render: (row) => <span className="text-xs bg-muted px-2 py-0.5 rounded font-medium">{row.strategy}</span>,
    },
    {
      key: 'metrics', header: 'Metrics',
      render: (row) => (
        <div className="flex gap-3 text-xs font-mono text-muted-foreground">
          {row.metrics.precision != null && <span>P:{row.metrics.precision.toFixed(3)}</span>}
          {row.metrics.recall != null && <span>R:{row.metrics.recall.toFixed(3)}</span>}
          {row.metrics.ndcg != null && <span>nDCG:{row.metrics.ndcg.toFixed(3)}</span>}
        </div>
      ),
    },
    {
      key: 'file_size_mb', header: 'Size',
      render: (row) => <span className="text-xs text-muted-foreground">{row.file_size_mb.toFixed(1)} MB</span>,
    },
    {
      key: 'created_at', header: 'Created', sortable: true,
      render: (row) => <span className="text-xs text-muted-foreground">{formatRelativeTime(row.created_at)}</span>,
    },
    {
      key: 'actions', header: '',
      render: (row) => (
        <div className="flex items-center gap-1" onClick={e => e.stopPropagation()}>
          <button
            onClick={() => navigate(`/models/${row.id}`)}
            className="p-1.5 rounded hover:bg-muted transition-colors" title="View"
          >
            <Eye className="w-3.5 h-3.5 text-muted-foreground" />
          </button>
          <button
            onClick={() => setDeleteTarget(row)}
            className="p-1.5 rounded hover:bg-red-500/10 hover:text-red-500 transition-colors" title="Delete"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      ),
    },
  ];

  return (
    <div className="flex flex-col h-full overflow-hidden">
      <PageHeader
        title="Models"
        breadcrumbs={[{ label: 'Dashboard', href: '/dashboard' }, { label: 'Models' }]}
        description="Browse and manage your trained recommendation models."
      />

      <div className="flex-1 overflow-y-auto">
        <div className="p-6 space-y-4">
          <div className="flex items-center gap-3 flex-wrap">
            <SearchBox value={search} onChange={v => { setSearch(v); setPage(1); }} placeholder="Search models…" className="w-56" />
            <div className="flex items-center gap-1">
              <span className="text-xs text-muted-foreground flex items-center gap-1"><Filter className="w-3 h-3" /> Strategy:</span>
              {[{ value: '', label: 'All' }, ...TRAINING_STRATEGIES.map(s => ({ value: s.value, label: s.label }))].map(opt => (
                <button
                  key={opt.value}
                  onClick={() => setStrategy(opt.value)}
                  className={`px-2.5 py-1 rounded text-xs transition-colors ${
                    strategy === opt.value ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:bg-muted'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
            {data && <span className="text-xs text-muted-foreground ml-auto">{data.total} model{data.total !== 1 ? 's' : ''}</span>}
          </div>

          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <DataTable
              columns={columns}
              data={data?.items ?? []}
              loading={isLoading}
              rowKey={r => r.id}
              onRowClick={r => navigate(`/models/${r.id}`)}
              emptyMessage="No models found"
              emptyDescription="Train a model to see it here"
              emptyIcon={<BrainCircuit className="w-6 h-6 text-muted-foreground" />}
            />
            {data && data.pages > 1 && (
              <Pagination page={data.page} pages={data.pages} total={data.total} pageSize={DEFAULT_PAGE_SIZE} onPageChange={setPage} />
            )}
          </div>
        </div>
      </div>

      <ConfirmationDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={() => deleteTarget && deleteMutation.mutate(deleteTarget.id)}
        title="Delete Model"
        description={`Delete "${deleteTarget?.name}"? This cannot be undone.`}
        confirmLabel="Delete"
        danger
        loading={deleteMutation.isPending}
      />
    </div>
  );
}
