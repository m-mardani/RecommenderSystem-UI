import { useParams, useNavigate } from 'react-router';
import { useQuery } from '@tanstack/react-query';
import { ArrowLeft, BrainCircuit, Loader2, Star } from 'lucide-react';
import {
  RadarChart, PolarGrid, PolarAngleAxis, Radar, ResponsiveContainer, Tooltip
} from 'recharts';
import { PageHeader } from '../../components/ui/PageHeader';
import { QUERY_KEYS } from '../../lib/constants';
import { modelService } from '../../services/modelService';
import { formatDate } from '../../lib/utils';

const CHART_TOOLTIP_STYLE = {
  contentStyle: { background: 'var(--card)', border: '1px solid var(--border)', borderRadius: '8px', fontSize: '12px' },
};

export function ModelDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const { data: model, isLoading } = useQuery({
    queryKey: QUERY_KEYS.model(id!),
    queryFn: () => modelService.get(id!),
    enabled: !!id,
  });

  if (isLoading) return (
    <div className="flex items-center justify-center h-full">
      <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
    </div>
  );
  if (!model) return null;

  const radarData = Object.entries(model.metrics)
    .filter(([, v]) => v != null)
    .map(([k, v]) => ({ metric: k.toUpperCase(), value: Math.round((v as number) * 100) }));

  return (
    <div className="flex flex-col h-full overflow-hidden">
      <PageHeader
        breadcrumbs={[
          { label: 'Dashboard', href: '/dashboard' },
          { label: 'Models', href: '/models' },
          { label: model.name },
        ]}
      />

      <div className="flex-1 overflow-y-auto">
        <div className="p-6 space-y-5">
          <div className="flex items-start gap-3">
            <button onClick={() => navigate('/models')} className="p-1.5 rounded hover:bg-muted transition-colors mt-0.5">
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div className="w-10 h-10 rounded-lg bg-violet-500/10 flex items-center justify-center">
              <BrainCircuit className="w-5 h-5 text-violet-500" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <h1 className="font-semibold">{model.name}</h1>
                {model.is_active && <Star className="w-4 h-4 text-amber-400 fill-amber-400" />}
              </div>
              <p className="text-sm text-muted-foreground">v{model.version} · {model.strategy} · {model.dataset_name}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {/* Metrics */}
            <div className="bg-card border border-border rounded-xl p-4">
              <h3 className="text-sm font-medium mb-4">Evaluation Metrics</h3>
              {radarData.length > 0 ? (
                <ResponsiveContainer width="100%" height={220}>
                  <RadarChart data={radarData} cx="50%" cy="50%" outerRadius={80}>
                    <PolarGrid stroke="var(--border)" />
                    <PolarAngleAxis dataKey="metric" tick={{ fontSize: 10, fill: 'var(--muted-foreground)' }} />
                    <Radar dataKey="value" stroke="#38bdf8" fill="#38bdf8" fillOpacity={0.2} strokeWidth={2} />
                    <Tooltip {...CHART_TOOLTIP_STYLE} formatter={(v: number) => [`${v}%`, 'Score']} />
                  </RadarChart>
                </ResponsiveContainer>
              ) : (
                <p className="text-sm text-muted-foreground">No metrics available</p>
              )}
              <div className="grid grid-cols-2 gap-2 mt-3">
                {Object.entries(model.metrics).filter(([, v]) => v != null).map(([k, v]) => (
                  <div key={k} className="flex items-center justify-between p-2 rounded bg-muted/30">
                    <span className="text-xs text-muted-foreground uppercase">{k}</span>
                    <span className="text-xs font-mono font-medium">{(v as number).toFixed(4)}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Info */}
            <div className="bg-card border border-border rounded-xl p-4">
              <h3 className="text-sm font-medium mb-4">Model Information</h3>
              <div className="space-y-3">
                {[
                  ['Strategy', model.strategy],
                  ['Version', model.version],
                  ['Dataset', model.dataset_name],
                  ['File Size', `${model.file_size_mb.toFixed(1)} MB`],
                  ['Training Job', model.training_job_id],
                  ['Created By', model.created_by],
                  ['Created At', formatDate(model.created_at)],
                  ['Status', model.is_active ? 'Active' : 'Inactive'],
                ].map(([label, value]) => (
                  <div key={label} className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">{label}</span>
                    <span className="text-xs font-medium">{value}</span>
                  </div>
                ))}
              </div>
              {model.tags && model.tags.length > 0 && (
                <div className="mt-4 pt-3 border-t border-border">
                  <p className="text-xs text-muted-foreground mb-2">Tags</p>
                  <div className="flex flex-wrap gap-1.5">
                    {model.tags.map(t => (
                      <span key={t} className="px-2 py-0.5 rounded-full bg-muted text-xs">{t}</span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
