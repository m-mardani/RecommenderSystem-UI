import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { toast } from 'sonner';
import { Zap, Loader2, TrendingUp, Plus, Trash2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { PageHeader } from '../../components/ui/PageHeader';
import { QUERY_KEYS } from '../../lib/constants';
import { modelService } from '../../services/modelService';
import { inferenceService } from '../../services/inferenceService';
import { RecommendationItem, PredictionResponse } from '../../types';

type Mode = 'recommend' | 'predict' | 'scenario';

export function InferencePage() {
  const [mode, setMode] = useState<Mode>('recommend');
  const [modelId, setModelId] = useState('');
  const [userId, setUserId] = useState('');
  const [itemId, setItemId] = useState('');
  const [topK, setTopK] = useState(10);
  const [scenarios, setScenarios] = useState([{ user_id: '', item_id: '' }]);
  const [results, setResults] = useState<RecommendationItem[] | PredictionResponse | null>(null);
  const [scenarioResults, setScenarioResults] = useState<{ score: number; user_id: string; item_id: string }[]>([]);

  const { data: models } = useQuery({
    queryKey: QUERY_KEYS.availableModels,
    queryFn: modelService.available,
  });

  const recommendMutation = useMutation({
    mutationFn: () => inferenceService.recommend({ model_id: modelId, user_id: userId, top_k: topK }),
    onSuccess: (data) => setResults(data.recommendations),
    onError: () => toast.error('Inference failed'),
  });

  const predictMutation = useMutation({
    mutationFn: () => inferenceService.predict({ model_id: modelId, user_id: userId, item_id: itemId }),
    onSuccess: (data) => setResults(data),
    onError: () => toast.error('Prediction failed'),
  });

  const scenarioMutation = useMutation({
    mutationFn: () => inferenceService.scenario({
      model_id: modelId,
      scenarios: scenarios.filter(s => s.user_id && s.item_id),
    }),
    onSuccess: (data) => setScenarioResults(
      data.results.map(r => ({ score: r.score, user_id: r.user_id, item_id: r.item_id }))
    ),
    onError: () => toast.error('Scenario prediction failed'),
  });

  const isLoading = recommendMutation.isPending || predictMutation.isPending || scenarioMutation.isPending;

  const handleRun = () => {
    if (!modelId) { toast.error('Select a model first'); return; }
    setResults(null);
    setScenarioResults([]);
    if (mode === 'recommend') recommendMutation.mutate();
    else if (mode === 'predict') predictMutation.mutate();
    else scenarioMutation.mutate();
  };

  const recommendations = Array.isArray(results) ? results : null;
  const prediction = results && !Array.isArray(results) ? results as PredictionResponse : null;

  return (
    <div className="flex flex-col h-full overflow-hidden">
      <PageHeader
        title="Inference"
        breadcrumbs={[{ label: 'Dashboard', href: '/dashboard' }, { label: 'Inference' }]}
        description="Run recommendations, predictions, and scenario analysis using trained models."
      />

      <div className="flex-1 overflow-y-auto">
        <div className="p-6 max-w-4xl mx-auto space-y-5">
          {/* Mode tabs */}
          <div className="flex gap-2">
            {([
              { id: 'recommend', label: 'Recommendations', icon: '🎯' },
              { id: 'predict', label: 'Prediction', icon: '🔮' },
              { id: 'scenario', label: 'Scenario', icon: '⚡' },
            ] as const).map(m => (
              <button
                key={m.id}
                onClick={() => { setMode(m.id); setResults(null); setScenarioResults([]); }}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  mode === m.id ? 'bg-primary text-primary-foreground' : 'bg-card border border-border hover:bg-muted'
                }`}
              >
                <span>{m.icon}</span> {m.label}
              </button>
            ))}
          </div>

          {/* Config panel */}
          <div className="bg-card border border-border rounded-xl p-5 space-y-4">
            {/* Model select */}
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Model *</label>
              <select
                value={modelId}
                onChange={e => setModelId(e.target.value)}
                className="w-full h-9 px-3 rounded-md border border-border bg-input-background text-sm focus:outline-none focus:ring-1 focus:ring-ring"
              >
                <option value="">Select a model…</option>
                {models?.map(m => (
                  <option key={m.id} value={m.id}>{m.name} ({m.strategy})</option>
                ))}
              </select>
            </div>

            {mode !== 'scenario' ? (
              <div className={`grid gap-4 ${mode === 'recommend' ? 'grid-cols-2' : 'grid-cols-3'}`}>
                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-1.5 block">User ID *</label>
                  <input
                    value={userId}
                    onChange={e => setUserId(e.target.value)}
                    placeholder="e.g. user_123"
                    className="w-full h-9 px-3 rounded-md border border-border bg-input-background text-sm focus:outline-none focus:ring-1 focus:ring-ring"
                  />
                </div>
                {mode === 'predict' && (
                  <div>
                    <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Item ID *</label>
                    <input
                      value={itemId}
                      onChange={e => setItemId(e.target.value)}
                      placeholder="e.g. item_456"
                      className="w-full h-9 px-3 rounded-md border border-border bg-input-background text-sm focus:outline-none focus:ring-1 focus:ring-ring"
                    />
                  </div>
                )}
                {mode === 'recommend' && (
                  <div>
                    <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Top-K Results</label>
                    <input
                      type="number"
                      value={topK}
                      min={1}
                      max={100}
                      onChange={e => setTopK(parseInt(e.target.value))}
                      className="w-full h-9 px-3 rounded-md border border-border bg-input-background text-sm focus:outline-none focus:ring-1 focus:ring-ring"
                    />
                  </div>
                )}
              </div>
            ) : (
              /* Scenarios */
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-medium text-muted-foreground">Scenarios</label>
                  <button
                    onClick={() => setScenarios(s => [...s, { user_id: '', item_id: '' }])}
                    className="flex items-center gap-1 text-xs text-primary hover:underline"
                  >
                    <Plus className="w-3 h-3" /> Add scenario
                  </button>
                </div>
                {scenarios.map((sc, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground w-5">{i + 1}</span>
                    <input
                      value={sc.user_id}
                      onChange={e => setScenarios(s => s.map((x, j) => j === i ? { ...x, user_id: e.target.value } : x))}
                      placeholder="user_id"
                      className="flex-1 h-8 px-2.5 rounded-md border border-border bg-input-background text-sm focus:outline-none focus:ring-1 focus:ring-ring"
                    />
                    <input
                      value={sc.item_id}
                      onChange={e => setScenarios(s => s.map((x, j) => j === i ? { ...x, item_id: e.target.value } : x))}
                      placeholder="item_id"
                      className="flex-1 h-8 px-2.5 rounded-md border border-border bg-input-background text-sm focus:outline-none focus:ring-1 focus:ring-ring"
                    />
                    {scenarios.length > 1 && (
                      <button onClick={() => setScenarios(s => s.filter((_, j) => j !== i))} className="p-1 text-muted-foreground hover:text-red-500 transition-colors">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}

            <button
              onClick={handleRun}
              disabled={isLoading}
              className="flex items-center gap-2 px-5 py-2 bg-primary text-primary-foreground rounded-md text-sm font-medium hover:bg-primary/90 transition-colors disabled:opacity-50"
            >
              {isLoading ? <><Loader2 className="w-4 h-4 animate-spin" /> Running…</> : <><Zap className="w-4 h-4" /> Run Inference</>}
            </button>
          </div>

          {/* Results */}
          <AnimatePresence>
            {(recommendations || prediction || scenarioResults.length > 0) && (
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-card border border-border rounded-xl overflow-hidden"
              >
                <div className="px-5 py-3 border-b border-border">
                  <h3 className="text-sm font-medium">Results</h3>
                </div>

                {recommendations && (
                  <div className="divide-y divide-border/50">
                    {recommendations.map((item, i) => (
                      <div key={item.item_id} className="flex items-center gap-4 px-5 py-3 hover:bg-muted/30 transition-colors">
                        <span className="w-6 text-xs text-muted-foreground font-mono">#{i + 1}</span>
                        <div className="flex-1">
                          <p className="text-sm font-medium">{item.item_id}</p>
                          {item.explanation && <p className="text-xs text-muted-foreground mt-0.5">{item.explanation}</p>}
                        </div>
                        <div className="flex items-center gap-1.5">
                          <TrendingUp className="w-3.5 h-3.5 text-emerald-500" />
                          <span className="text-sm font-mono font-semibold text-emerald-500">
                            {(item.score * 100).toFixed(1)}%
                          </span>
                        </div>
                        <div className="w-24 h-1.5 bg-muted rounded-full overflow-hidden">
                          <div
                            className="h-full bg-emerald-500 rounded-full"
                            style={{ width: `${Math.min(100, item.score * 100)}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {prediction && (
                  <div className="p-5 space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium">User: <span className="font-mono">{prediction.user_id}</span></p>
                        <p className="text-sm text-muted-foreground">Item: <span className="font-mono">{prediction.item_id}</span></p>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-semibold text-emerald-500">{(prediction.score * 100).toFixed(1)}%</p>
                        <p className="text-xs text-muted-foreground">{prediction.inference_time_ms?.toFixed(0)}ms</p>
                      </div>
                    </div>
                    {prediction.explanation && (
                      <p className="text-sm text-muted-foreground bg-muted/30 p-3 rounded-lg">{prediction.explanation}</p>
                    )}
                  </div>
                )}

                {scenarioResults.length > 0 && (
                  <div className="divide-y divide-border/50">
                    {scenarioResults.map((r, i) => (
                      <div key={i} className="flex items-center gap-4 px-5 py-3">
                        <span className="text-xs text-muted-foreground w-5">#{i + 1}</span>
                        <span className="text-sm font-mono flex-1">{r.user_id} → {r.item_id}</span>
                        <span className="text-sm font-mono font-semibold text-emerald-500">{(r.score * 100).toFixed(1)}%</span>
                      </div>
                    ))}
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
