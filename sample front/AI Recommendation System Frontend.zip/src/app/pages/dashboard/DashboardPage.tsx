import { useQuery } from '@tanstack/react-query';
import { motion } from 'motion/react';
import {
  Database, BrainCircuit, Activity, HardDrive, Cpu, Zap,
  ArrowRight, Plus, Upload, Play
} from 'lucide-react';
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from 'recharts';
import { useNavigate } from 'react-router';
import { MetricCard } from '../../components/ui/MetricCard';
import { StatusBadge } from '../../components/ui/StatusBadge';
import { PageHeader } from '../../components/ui/PageHeader';
import { QUERY_KEYS } from '../../lib/constants';
import { monitoringService } from '../../services/monitoringService';
import { trainingService } from '../../services/trainingService';
import { formatRelativeTime } from '../../lib/utils';
import { useAuthStore } from '../../store/authStore';

const MOCK_GROWTH = [
  { month: 'Feb', datasets: 8, models: 4 },
  { month: 'Mar', datasets: 12, models: 6 },
  { month: 'Apr', datasets: 19, models: 9 },
  { month: 'May', datasets: 24, models: 14 },
  { month: 'Jun', datasets: 31, models: 18 },
  { month: 'Jul', datasets: 38, models: 23 },
  { month: 'Aug', datasets: 45, models: 27 },
];

const MOCK_JOB_TIMELINE = [
  { day: 'Mon', completed: 5, failed: 1 },
  { day: 'Tue', completed: 8, failed: 0 },
  { day: 'Wed', completed: 3, failed: 2 },
  { day: 'Thu', completed: 11, failed: 1 },
  { day: 'Fri', completed: 7, failed: 0 },
  { day: 'Sat', completed: 4, failed: 1 },
  { day: 'Sun', completed: 6, failed: 0 },
];

const MODEL_DIST = [
  { name: 'Collaborative', value: 35, color: '#38bdf8' },
  { name: 'Content-Based', value: 25, color: '#a78bfa' },
  { name: 'Hybrid', value: 28, color: '#34d399' },
  { name: 'Neural', value: 12, color: '#fbbf24' },
];

const CHART_TOOLTIP_STYLE = {
  contentStyle: {
    background: 'var(--card)',
    border: '1px solid var(--border)',
    borderRadius: '8px',
    fontSize: '12px',
    color: 'var(--foreground)',
  },
  itemStyle: { color: 'var(--muted-foreground)' },
};

export function DashboardPage() {
  const navigate = useNavigate();
  const { user } = useAuthStore();

  const { data: snapshot } = useQuery({
    queryKey: QUERY_KEYS.systemSnapshot,
    queryFn: monitoringService.snapshot,
    refetchInterval: 30_000,
  });

  const { data: jobsData } = useQuery({
    queryKey: QUERY_KEYS.trainingJobs,
    queryFn: () => trainingService.list({ page: 1, page_size: 5 }),
    refetchInterval: 15_000,
  });

  const recentJobs = jobsData?.items ?? [];

  return (
    <div className="flex flex-col h-full overflow-hidden">
      <PageHeader
        title="Dashboard"
        breadcrumbs={[{ label: 'Dashboard' }]}
        actions={
          <div className="flex items-center gap-2">
            <button
              onClick={() => navigate('/datasets')}
              className="flex items-center gap-1.5 h-8 px-3 rounded-md text-sm border border-border hover:bg-muted transition-colors"
            >
              <Upload className="w-3.5 h-3.5" /> Upload Dataset
            </button>
            <button
              onClick={() => navigate('/training')}
              className="flex items-center gap-1.5 h-8 px-3 rounded-md text-sm bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" /> New Training
            </button>
          </div>
        }
      />

      <div className="flex-1 overflow-y-auto">
        <div className="p-6 space-y-6">
          {/* Welcome */}
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-r from-primary/10 via-violet-500/5 to-transparent rounded-xl border border-primary/20 p-5"
          >
            <h2 className="font-semibold text-foreground">
              Welcome back, {user?.full_name || user?.username} 👋
            </h2>
            <p className="text-sm text-muted-foreground mt-1">
              {snapshot?.active_jobs
                ? `${snapshot.active_jobs} training job${snapshot.active_jobs !== 1 ? 's' : ''} running right now.`
                : 'Everything looks healthy. No active training jobs.'}
            </p>
          </motion.div>

          {/* KPIs */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <MetricCard
              title="Datasets"
              value={snapshot?.total_datasets ?? 45}
              subtitle="Total uploaded"
              icon={Database}
              color="blue"
              trend={{ value: 12, label: 'this month' }}
            />
            <MetricCard
              title="Models"
              value={snapshot?.total_models ?? 27}
              subtitle="Trained & ready"
              icon={BrainCircuit}
              color="purple"
              trend={{ value: 8, label: 'this month' }}
            />
            <MetricCard
              title="Active Jobs"
              value={snapshot?.active_jobs ?? 3}
              subtitle={`${snapshot?.pending_jobs ?? 1} pending`}
              icon={Cpu}
              color="amber"
            />
            <MetricCard
              title="Storage Used"
              value={snapshot?.metrics ? `${snapshot.metrics.disk_used_gb.toFixed(1)} GB` : '48.2 GB'}
              subtitle={snapshot?.metrics ? `${Math.round(snapshot.metrics.disk_percent)}% of total` : '64% of 75 GB'}
              icon={HardDrive}
              color="emerald"
            />
          </div>

          {/* Charts row */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* Growth chart */}
            <div className="lg:col-span-2 bg-card border border-border rounded-xl p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-medium text-sm">Dataset & Model Growth</h3>
                <span className="text-xs text-muted-foreground">Last 7 months</span>
              </div>
              <ResponsiveContainer width="100%" height={200}>
                <AreaChart data={MOCK_GROWTH} margin={{ top: 0, right: 0, bottom: 0, left: -20 }}>
                  <defs>
                    <linearGradient id="gradDatasets" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#38bdf8" stopOpacity={0.2} />
                      <stop offset="95%" stopColor="#38bdf8" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="gradModels" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#a78bfa" stopOpacity={0.2} />
                      <stop offset="95%" stopColor="#a78bfa" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="month" tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                  <Tooltip {...CHART_TOOLTIP_STYLE} />
                  <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                  <Area type="monotone" dataKey="datasets" stroke="#38bdf8" fill="url(#gradDatasets)" strokeWidth={2} name="Datasets" />
                  <Area type="monotone" dataKey="models" stroke="#a78bfa" fill="url(#gradModels)" strokeWidth={2} name="Models" />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            {/* Model distribution */}
            <div className="bg-card border border-border rounded-xl p-4">
              <h3 className="font-medium text-sm mb-4">Model Distribution</h3>
              <ResponsiveContainer width="100%" height={160}>
                <PieChart>
                  <Pie data={MODEL_DIST} cx="50%" cy="50%" innerRadius={45} outerRadius={70} dataKey="value" paddingAngle={3}>
                    {MODEL_DIST.map((entry) => (
                      <Cell key={entry.name} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip {...CHART_TOOLTIP_STYLE} />
                </PieChart>
              </ResponsiveContainer>
              <div className="space-y-1.5 mt-2">
                {MODEL_DIST.map(d => (
                  <div key={d.name} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full" style={{ background: d.color }} />
                      <span className="text-xs text-muted-foreground">{d.name}</span>
                    </div>
                    <span className="text-xs font-medium">{d.value}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Job timeline + Recent activity */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* Job timeline */}
            <div className="lg:col-span-2 bg-card border border-border rounded-xl p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-medium text-sm">Job Timeline (7 days)</h3>
              </div>
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={MOCK_JOB_TIMELINE} margin={{ top: 0, right: 0, bottom: 0, left: -20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="day" tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                  <Tooltip {...CHART_TOOLTIP_STYLE} />
                  <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                  <Bar dataKey="completed" fill="#34d399" radius={[3, 3, 0, 0]} name="Completed" />
                  <Bar dataKey="failed" fill="#f87171" radius={[3, 3, 0, 0]} name="Failed" />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Quick actions */}
            <div className="bg-card border border-border rounded-xl p-4">
              <h3 className="font-medium text-sm mb-4">Quick Actions</h3>
              <div className="space-y-2">
                {[
                  { label: 'Upload Dataset', icon: Upload, href: '/datasets', color: 'text-sky-500' },
                  { label: 'Start Training', icon: Play, href: '/training', color: 'text-emerald-500' },
                  { label: 'Run Inference', icon: Zap, href: '/inference', color: 'text-amber-500' },
                  { label: 'View Monitoring', icon: Activity, href: '/monitoring', color: 'text-violet-500' },
                ].map(({ label, icon: Icon, href, color }) => (
                  <button
                    key={href}
                    onClick={() => navigate(href)}
                    className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-muted/50 transition-colors group"
                  >
                    <div className="flex items-center gap-3">
                      <Icon className={`w-4 h-4 ${color}`} />
                      <span className="text-sm">{label}</span>
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-muted-foreground group-hover:translate-x-0.5 transition-transform" />
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Recent training jobs */}
          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 border-b border-border">
              <h3 className="font-medium text-sm">Recent Training Jobs</h3>
              <button
                onClick={() => navigate('/training')}
                className="text-xs text-primary hover:underline flex items-center gap-1"
              >
                View all <ArrowRight className="w-3 h-3" />
              </button>
            </div>
            {recentJobs.length === 0 ? (
              <div className="p-8 text-center">
                <p className="text-sm text-muted-foreground">No training jobs yet.</p>
                <button
                  onClick={() => navigate('/training')}
                  className="mt-3 text-xs text-primary hover:underline"
                >
                  Start your first training →
                </button>
              </div>
            ) : (
              <div className="divide-y divide-border/50">
                {recentJobs.map(job => (
                  <div
                    key={job.id}
                    onClick={() => navigate(`/training/${job.id}`)}
                    className="flex items-center gap-4 px-5 py-3 hover:bg-muted/30 cursor-pointer transition-colors"
                  >
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{job.name}</p>
                      <p className="text-xs text-muted-foreground">{job.dataset_name} · {formatRelativeTime(job.created_at)}</p>
                    </div>
                    <StatusBadge status={job.status} size="sm" />
                    {job.status === 'RUNNING' && (
                      <div className="w-20">
                        <div className="h-1 bg-muted rounded-full overflow-hidden">
                          <div className="h-full bg-sky-500 rounded-full transition-all" style={{ width: `${job.progress}%` }} />
                        </div>
                        <p className="text-xs text-muted-foreground mt-0.5 text-right">{job.progress}%</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* System metrics */}
          {snapshot?.metrics && (
            <div className="grid grid-cols-3 gap-4">
              {[
                { label: 'CPU', value: snapshot.metrics.cpu_percent, color: 'sky' as const },
                { label: 'Memory', value: snapshot.metrics.memory_percent, color: 'violet' as const },
                { label: 'Disk', value: snapshot.metrics.disk_percent, color: 'emerald' as const },
              ].map(({ label, value, color }) => (
                <div key={label} className="bg-card border border-border rounded-xl p-4">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm font-medium">{label}</span>
                    <span className="text-sm font-mono text-muted-foreground">{Math.round(value)}%</span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${
                        color === 'sky' ? 'bg-sky-500' : color === 'violet' ? 'bg-violet-500' : 'bg-emerald-500'
                      }`}
                      style={{ width: `${value}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
