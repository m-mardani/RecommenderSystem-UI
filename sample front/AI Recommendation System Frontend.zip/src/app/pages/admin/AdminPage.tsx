import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Users, Plus, Trash2, ShieldCheck, Clock, X, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { PageHeader } from '../../components/ui/PageHeader';
import { DataTable, Column } from '../../components/ui/DataTable';
import { RoleBadge } from '../../components/ui/StatusBadge';
import { Pagination } from '../../components/ui/Pagination';
import { SearchBox } from '../../components/ui/SearchBox';
import { ConfirmationDialog } from '../../components/ui/ConfirmationDialog';
import { QUERY_KEYS, DEFAULT_PAGE_SIZE } from '../../lib/constants';
import { adminService } from '../../services/adminService';
import { User, AuditLog } from '../../types';
import { formatRelativeTime, formatDate } from '../../lib/utils';

const createUserSchema = z.object({
  username: z.string().min(3),
  email: z.string().email(),
  password: z.string().min(8),
  full_name: z.string().optional(),
  role: z.enum(['ADMIN', 'USER']),
});
type CreateUserForm = z.infer<typeof createUserSchema>;

type Tab = 'users' | 'audit' | 'presence';

export function AdminPage() {
  const [tab, setTab] = useState<Tab>('users');
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [createOpen, setCreateOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<User | null>(null);
  const queryClient = useQueryClient();

  const { data: usersData, isLoading: usersLoading } = useQuery({
    queryKey: [...QUERY_KEYS.users, page, search],
    queryFn: () => adminService.listUsers({ page, page_size: DEFAULT_PAGE_SIZE, search }),
    enabled: tab === 'users',
    placeholderData: prev => prev,
  });

  const { data: auditData, isLoading: auditLoading } = useQuery({
    queryKey: [...QUERY_KEYS.auditLogs, page],
    queryFn: () => adminService.auditLogs({ page, page_size: DEFAULT_PAGE_SIZE }),
    enabled: tab === 'audit',
    placeholderData: prev => prev,
  });

  const { data: onlineUsers } = useQuery({
    queryKey: QUERY_KEYS.onlineUsers,
    queryFn: adminService.onlineUsers,
    enabled: tab === 'presence',
    refetchInterval: 15_000,
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => adminService.deleteUser(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.users });
      toast.success('User deleted');
      setDeleteTarget(null);
    },
    onError: () => toast.error('Failed to delete user'),
  });

  const userColumns: Column<User>[] = [
    {
      key: 'username', header: 'User',
      render: (row) => (
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center text-xs font-medium text-primary shrink-0">
            {(row.full_name || row.username).charAt(0).toUpperCase()}
          </div>
          <div>
            <p className="text-sm font-medium">{row.full_name || row.username}</p>
            <p className="text-xs text-muted-foreground">{row.email}</p>
          </div>
        </div>
      ),
    },
    { key: 'username', header: 'Username', render: (row) => <span className="font-mono text-xs">{row.username}</span> },
    { key: 'role', header: 'Role', render: (row) => <RoleBadge role={row.role} /> },
    {
      key: 'is_active', header: 'Status',
      render: (row) => (
        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${row.is_active ? 'bg-emerald-500/10 text-emerald-500' : 'bg-red-500/10 text-red-500'}`}>
          {row.is_active ? 'Active' : 'Inactive'}
        </span>
      ),
    },
    {
      key: 'last_login', header: 'Last Login',
      render: (row) => <span className="text-xs text-muted-foreground">{row.last_login ? formatRelativeTime(row.last_login) : 'Never'}</span>,
    },
    {
      key: 'created_at', header: 'Created',
      render: (row) => <span className="text-xs text-muted-foreground">{formatRelativeTime(row.created_at)}</span>,
    },
    {
      key: 'actions', header: '',
      render: (row) => (
        <button onClick={e => { e.stopPropagation(); setDeleteTarget(row); }} className="p-1.5 rounded hover:bg-red-500/10 hover:text-red-500 transition-colors">
          <Trash2 className="w-3.5 h-3.5" />
        </button>
      ),
    },
  ];

  const auditColumns: Column<AuditLog>[] = [
    { key: 'timestamp', header: 'Time', render: (row) => <span className="text-xs font-mono text-muted-foreground">{formatDate(row.timestamp)}</span> },
    { key: 'username', header: 'User', render: (row) => <span className="text-xs font-medium">{row.username}</span> },
    { key: 'action', header: 'Action', render: (row) => <span className="text-xs font-mono bg-muted px-1.5 py-0.5 rounded">{row.action}</span> },
    { key: 'resource_type', header: 'Resource', render: (row) => <span className="text-xs text-muted-foreground">{row.resource_type}</span> },
    {
      key: 'success', header: 'Result',
      render: (row) => (
        <span className={`text-xs font-medium ${row.success ? 'text-emerald-500' : 'text-red-500'}`}>
          {row.success ? '✓ OK' : '✗ Failed'}
        </span>
      ),
    },
    { key: 'ip_address', header: 'IP', render: (row) => <span className="text-xs font-mono text-muted-foreground">{row.ip_address ?? '—'}</span> },
  ];

  return (
    <div className="flex flex-col h-full overflow-hidden">
      <PageHeader
        title="Administration"
        breadcrumbs={[{ label: 'Dashboard', href: '/dashboard' }, { label: 'Administration' }]}
        description="Manage users, roles, audit logs, and monitor active sessions."
        actions={
          tab === 'users' ? (
            <button
              onClick={() => setCreateOpen(true)}
              className="flex items-center gap-1.5 h-8 px-3 rounded-md text-sm bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" /> Add User
            </button>
          ) : undefined
        }
      />

      <div className="flex-1 overflow-y-auto">
        <div className="p-6 space-y-4">
          {/* Tabs */}
          <div className="flex gap-1 border-b border-border">
            {[
              { id: 'users', label: 'Users', icon: Users },
              { id: 'audit', label: 'Audit Logs', icon: Clock },
              { id: 'presence', label: 'Online Users', icon: ShieldCheck },
            ].map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => { setTab(id as Tab); setPage(1); }}
                className={`flex items-center gap-2 px-4 py-2.5 text-sm border-b-2 transition-colors ${
                  tab === id ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />{label}
                {id === 'presence' && onlineUsers && (
                  <span className="w-4 h-4 rounded-full bg-emerald-500 text-white text-[10px] flex items-center justify-center">
                    {onlineUsers.length}
                  </span>
                )}
              </button>
            ))}
          </div>

          {tab === 'users' && (
            <>
              <SearchBox value={search} onChange={v => { setSearch(v); setPage(1); }} placeholder="Search users…" className="w-56" />
              <div className="bg-card border border-border rounded-xl overflow-hidden">
                <DataTable
                  columns={userColumns}
                  data={usersData?.items ?? []}
                  loading={usersLoading}
                  rowKey={r => r.id}
                  emptyMessage="No users found"
                  emptyIcon={<Users className="w-5 h-5 text-muted-foreground" />}
                />
                {usersData && usersData.pages > 1 && (
                  <Pagination page={usersData.page} pages={usersData.pages} total={usersData.total} pageSize={DEFAULT_PAGE_SIZE} onPageChange={setPage} />
                )}
              </div>
            </>
          )}

          {tab === 'audit' && (
            <div className="bg-card border border-border rounded-xl overflow-hidden">
              <DataTable
                columns={auditColumns}
                data={auditData?.items ?? []}
                loading={auditLoading}
                rowKey={r => r.id}
                emptyMessage="No audit logs"
                emptyIcon={<Clock className="w-5 h-5 text-muted-foreground" />}
              />
              {auditData && auditData.pages > 1 && (
                <Pagination page={auditData.page} pages={auditData.pages} total={auditData.total} pageSize={DEFAULT_PAGE_SIZE} onPageChange={setPage} />
              )}
            </div>
          )}

          {tab === 'presence' && (
            <div className="bg-card border border-border rounded-xl overflow-hidden">
              {onlineUsers && onlineUsers.length === 0 ? (
                <div className="py-12 text-center text-sm text-muted-foreground">No users currently online</div>
              ) : (
                <div className="divide-y divide-border/50">
                  {(onlineUsers ?? []).map(u => (
                    <div key={u.user_id} className="flex items-center gap-4 px-5 py-3">
                      <div className="w-2 h-2 rounded-full bg-emerald-500" />
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-xs font-medium text-primary">
                        {u.username.charAt(0).toUpperCase()}
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">{u.username}</p>
                        <p className="text-xs text-muted-foreground">Connected {formatRelativeTime(u.connected_at)}</p>
                      </div>
                      <RoleBadge role={u.role} />
                      {u.ip_address && <span className="text-xs font-mono text-muted-foreground">{u.ip_address}</span>}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Create User Dialog */}
      <CreateUserDialog open={createOpen} onClose={() => setCreateOpen(false)} />

      <ConfirmationDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={() => deleteTarget && deleteMutation.mutate(deleteTarget.id)}
        title="Delete User"
        description={`Delete user "${deleteTarget?.username}"? This action cannot be undone.`}
        confirmLabel="Delete"
        danger
        loading={deleteMutation.isPending}
      />
    </div>
  );
}

function CreateUserDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const queryClient = useQueryClient();
  const { register, handleSubmit, reset, formState: { errors } } = useForm<CreateUserForm>({
    resolver: zodResolver(createUserSchema),
    defaultValues: { role: 'USER' },
  });

  const mutation = useMutation({
    mutationFn: (data: CreateUserForm) => adminService.createUser(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.users });
      toast.success('User created');
      reset();
      onClose();
    },
    onError: () => toast.error('Failed to create user'),
  });

  return (
    <AnimatePresence>
      {open && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={onClose}>
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }}
            onClick={e => e.stopPropagation()}
            className="bg-card border border-border rounded-xl p-6 w-full max-w-md shadow-2xl">
            <div className="flex items-center justify-between mb-5">
              <h3 className="font-semibold">Create User</h3>
              <button onClick={onClose}><X className="w-4 h-4 text-muted-foreground" /></button>
            </div>
            <form onSubmit={handleSubmit(d => mutation.mutate(d))} className="space-y-3">
              {[
                { name: 'username', label: 'Username *', placeholder: 'johndoe' },
                { name: 'email', label: 'Email *', placeholder: 'john@example.com' },
                { name: 'full_name', label: 'Full Name', placeholder: 'John Doe' },
                { name: 'password', label: 'Password *', placeholder: '••••••••', type: 'password' },
              ].map(({ name, label, placeholder, type }) => (
                <div key={name}>
                  <label className="text-xs font-medium text-muted-foreground mb-1 block">{label}</label>
                  <input
                    {...register(name as keyof CreateUserForm)}
                    type={type ?? 'text'}
                    placeholder={placeholder}
                    className="w-full h-9 px-3 rounded-md border border-border bg-input-background text-sm focus:outline-none focus:ring-1 focus:ring-ring"
                  />
                  {errors[name as keyof CreateUserForm] && (
                    <p className="text-xs text-red-500 mt-0.5">{errors[name as keyof CreateUserForm]?.message}</p>
                  )}
                </div>
              ))}
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Role *</label>
                <select {...register('role')} className="w-full h-9 px-3 rounded-md border border-border bg-input-background text-sm focus:outline-none focus:ring-1 focus:ring-ring">
                  <option value="USER">User</option>
                  <option value="ADMIN">Admin</option>
                </select>
              </div>
              <div className="flex justify-end gap-3 pt-2">
                <button type="button" onClick={onClose} className="px-4 py-2 rounded-md text-sm border border-border hover:bg-muted transition-colors">
                  Cancel
                </button>
                <button type="submit" disabled={mutation.isPending} className="flex items-center gap-2 px-4 py-2 rounded-md text-sm bg-primary text-primary-foreground hover:bg-primary/90 transition-colors disabled:opacity-50">
                  {mutation.isPending ? <><Loader2 className="w-3.5 h-3.5 animate-spin" /> Creating…</> : 'Create User'}
                </button>
              </div>
            </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
