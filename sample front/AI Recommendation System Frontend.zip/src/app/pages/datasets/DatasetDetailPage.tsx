import { useState } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router';
import { useQuery } from '@tanstack/react-query';
import { ArrowLeft, Database, BarChart2, Table2, Loader2 } from 'lucide-react';
import { QUERY_KEYS } from '../../lib/constants';
import { datasetService } from '../../services/datasetService';
import { StatusBadge } from '../../components/ui/StatusBadge';
import { PageHeader } from '../../components/ui/PageHeader';
import { ProgressCard } from '../../components/ui/ProgressCard';
import { formatBytes, formatDate } from '../../lib/utils';

export function DatasetDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [activeTab, setActiveTab] = useState(searchParams.get('tab') || 'preview');
  const [previewPage, setPreviewPage] = useState(1);

  const { data: dataset } = useQuery({
    queryKey: QUERY_KEYS.dataset(id!),
    queryFn: () => datasetService.get(id!),
    enabled: !!id,
  });

  const { data: preview, isLoading: previewLoading } = useQuery({
    queryKey: [...QUERY_KEYS.datasetPreview(id!), previewPage],
    queryFn: () => datasetService.preview(id!, previewPage, 50),
    enabled: !!id && activeTab === 'preview',
  });

  const { data: analysis, isLoading: analysisLoading } = useQuery({
    queryKey: QUERY_KEYS.datasetAnalysis(id!),
    queryFn: () => datasetService.analyze(id!),
    enabled: !!id && activeTab === 'analysis',
  });

  if (!dataset) return (
    <div className="flex items-center justify-center h-full">
      <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
    </div>
  );

  return (
    <div className="flex flex-col h-full overflow-hidden">
      <PageHeader
        breadcrumbs={[
          { label: 'Dashboard', href: '/dashboard' },
          { label: 'Datasets', href: '/datasets' },
          { label: dataset.name },
        ]}
      />

      <div className="flex-1 overflow-y-auto">
        <div className="p-6 space-y-5">
          {/* Header */}
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <button onClick={() => navigate('/datasets')} className="p-1.5 rounded hover:bg-muted transition-colors">
                <ArrowLeft className="w-4 h-4" />
              </button>
              <div className="w-10 h-10 rounded-lg bg-sky-500/10 flex items-center justify-center">
                <Database className="w-5 h-5 text-sky-500" />
              </div>
              <div>
                <h1 className="font-semibold">{dataset.name}</h1>
                {dataset.description && <p className="text-sm text-muted-foreground">{dataset.description}</p>}
              </div>
            </div>
            <StatusBadge status={dataset.status} />
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            {[
              { label: 'Rows', value: dataset.row_count?.toLocaleString() ?? '—' },
              { label: 'Columns', value: dataset.column_count ?? '—' },
              { label: 'File Size', value: formatBytes(dataset.file_size) },
              { label: 'Created', value: formatDate(dataset.created_at) },
            ].map(({ label, value }) => (
              <div key={label} className="bg-card border border-border rounded-lg p-3">
                <p className="text-xs text-muted-foreground">{label}</p>
                <p className="text-sm font-medium mt-0.5">{value}</p>
              </div>
            ))}
          </div>

          {/* Tabs */}
          <div className="flex gap-1 border-b border-border">
            {[
              { id: 'preview', label: 'Preview', icon: Table2 },
              { id: 'analysis', label: 'Analysis', icon: BarChart2 },
            ].map(({ id: tabId, label, icon: Icon }) => (
              <button
                key={tabId}
                onClick={() => setActiveTab(tabId)}
                className={`flex items-center gap-2 px-4 py-2.5 text-sm border-b-2 transition-colors ${
                  activeTab === tabId
                    ? 'border-primary text-primary'
                    : 'border-transparent text-muted-foreground hover:text-foreground'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {label}
              </button>
            ))}
          </div>

          {/* Preview Tab */}
          {activeTab === 'preview' && (
            <div className="bg-card border border-border rounded-xl overflow-hidden">
              {previewLoading ? (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
                </div>
              ) : preview ? (
                <>
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs">
                      <thead>
                        <tr className="border-b border-border bg-muted/30">
                          {preview.columns.map(col => (
                            <th key={col} className="text-left px-3 py-2 font-medium text-muted-foreground whitespace-nowrap">
                              {col}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {preview.rows.map((row, i) => (
                          <tr key={i} className="border-b border-border/30 hover:bg-muted/20 transition-colors">
                            {preview.columns.map(col => (
                              <td key={col} className="px-3 py-2 font-mono text-xs text-muted-foreground whitespace-nowrap max-w-[200px] truncate">
                                {String(row[col] ?? '')}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <div className="px-4 py-3 border-t border-border flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">
                      Showing {(previewPage - 1) * 50 + 1}–{Math.min(previewPage * 50, preview.total_rows)} of {preview.total_rows.toLocaleString()} rows
                    </span>
                    <div className="flex items-center gap-2">
                      <button
                        disabled={previewPage === 1}
                        onClick={() => setPreviewPage(p => p - 1)}
                        className="px-3 py-1 text-xs rounded border border-border hover:bg-muted disabled:opacity-40 transition-colors"
                      >
                        Prev
                      </button>
                      <span className="text-xs text-muted-foreground">{previewPage}</span>
                      <button
                        disabled={previewPage * 50 >= preview.total_rows}
                        onClick={() => setPreviewPage(p => p + 1)}
                        className="px-3 py-1 text-xs rounded border border-border hover:bg-muted disabled:opacity-40 transition-colors"
                      >
                        Next
                      </button>
                    </div>
                  </div>
                </>
              ) : (
                <div className="py-12 text-center text-sm text-muted-foreground">No preview available</div>
              )}
            </div>
          )}

          {/* Analysis Tab */}
          {activeTab === 'analysis' && (
            <div className="space-y-4">
              {analysisLoading ? (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
                </div>
              ) : analysis ? (
                <>
                  <div className="grid grid-cols-3 gap-3">
                    <div className="bg-card border border-border rounded-lg p-3">
                      <p className="text-xs text-muted-foreground">Missing Data</p>
                      <ProgressCard label="" value={analysis.missing_percentage} max={100} unit="%" color="amber" size="sm" className="mt-2" />
                    </div>
                    <div className="bg-card border border-border rounded-lg p-3">
                      <p className="text-xs text-muted-foreground">Memory Usage</p>
                      <p className="text-sm font-medium mt-0.5">{analysis.memory_usage_mb.toFixed(1)} MB</p>
                    </div>
                    <div className="bg-card border border-border rounded-lg p-3">
                      <p className="text-xs text-muted-foreground">Analyzed</p>
                      <p className="text-sm font-medium mt-0.5">{formatDate(analysis.analyzed_at)}</p>
                    </div>
                  </div>

                  <div className="bg-card border border-border rounded-xl overflow-hidden">
                    <div className="px-4 py-3 border-b border-border">
                      <h3 className="text-sm font-medium">Column Statistics</h3>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="border-b border-border bg-muted/30">
                            {['Column', 'Type', 'Nulls', 'Unique', 'Min', 'Max', 'Mean'].map(h => (
                              <th key={h} className="text-left px-4 py-2.5 text-xs font-medium text-muted-foreground">{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {analysis.columns.map(col => (
                            <tr key={col.name} className="border-b border-border/50 hover:bg-muted/20 transition-colors">
                              <td className="px-4 py-2.5 font-medium">{col.name}</td>
                              <td className="px-4 py-2.5"><span className="font-mono text-xs bg-muted px-1.5 py-0.5 rounded">{col.dtype}</span></td>
                              <td className="px-4 py-2.5 text-xs text-muted-foreground">{col.null_count}</td>
                              <td className="px-4 py-2.5 text-xs text-muted-foreground">{col.unique_count}</td>
                              <td className="px-4 py-2.5 text-xs font-mono text-muted-foreground">{col.min ?? '—'}</td>
                              <td className="px-4 py-2.5 text-xs font-mono text-muted-foreground">{col.max ?? '—'}</td>
                              <td className="px-4 py-2.5 text-xs font-mono text-muted-foreground">{col.mean != null ? col.mean.toFixed(3) : '—'}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </>
              ) : (
                <div className="py-12 text-center text-sm text-muted-foreground">Analysis not available</div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
