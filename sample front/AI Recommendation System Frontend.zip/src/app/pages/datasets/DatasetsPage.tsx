import { useState, useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router';
import { useDropzone } from 'react-dropzone';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner';
import {
  Upload, Search, Database, Trash2, Eye, BarChart2, Plus, X, FileText, Loader2
} from 'lucide-react';
import { PageHeader } from '../../components/ui/PageHeader';
import { DataTable, Column } from '../../components/ui/DataTable';
import { StatusBadge } from '../../components/ui/StatusBadge';
import { Pagination } from '../../components/ui/Pagination';
import { SearchBox } from '../../components/ui/SearchBox';
import { ConfirmationDialog } from '../../components/ui/ConfirmationDialog';
import { EmptyState } from '../../components/ui/EmptyState';
import { QUERY_KEYS, DEFAULT_PAGE_SIZE } from '../../lib/constants';
import { datasetService } from '../../services/datasetService';
import { Dataset } from '../../types';
import { formatBytes, formatRelativeTime } from '../../lib/utils';

export function DatasetsPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [uploadOpen, setUploadOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Dataset | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: [...QUERY_KEYS.datasets, page, search],
    queryFn: () => datasetService.list({ page, page_size: DEFAULT_PAGE_SIZE, search }),
    placeholderData: prev => prev,
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => datasetService.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.datasets });
      toast.success('Dataset deleted');
      setDeleteTarget(null);
    },
    onError: () => toast.error('Failed to delete dataset'),
  });

  const columns: Column<Dataset>[] = [
    {
      key: 'name', header: 'Name', sortable: true,
      render: (row) => (
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded bg-sky-500/10 flex items-center justify-center shrink-0">
            <Database className="w-3.5 h-3.5 text-sky-500" />
          </div>
          <div>
            <p className="font-medium text-sm">{row.name}</p>
            {row.description && <p className="text-xs text-muted-foreground truncate max-w-xs">{row.description}</p>}
          </div>
        </div>
      ),
    },
    {
      key: 'status', header: 'Status',
      render: (row) => <StatusBadge status={row.status} size="sm" />,
    },
    {
      key: 'row_count', header: 'Rows',
      render: (row) => <span className="font-mono text-xs">{row.row_count?.toLocaleString() ?? '—'}</span>,
    },
    {
      key: 'column_count', header: 'Cols',
      render: (row) => <span className="font-mono text-xs">{row.column_count ?? '—'}</span>,
    },
    {
      key: 'file_size', header: 'Size',
      render: (row) => <span className="text-xs text-muted-foreground">{formatBytes(row.file_size)}</span>,
    },
    {
      key: 'created_at', header: 'Created', sortable: true,
      render: (row) => <span className="text-xs text-muted-foreground">{formatRelativeTime(row.created_at)}</span>,
    },
    {
      key: 'actions', header: '',
      render: (row) => (
        <div className="flex items-center gap-1" onClick={e => e.stopPropagation()}>
          <button
            onClick={() => navigate(`/datasets/${row.id}`)}
            className="p-1.5 rounded hover:bg-muted transition-colors" title="Preview"
          >
            <Eye className="w-3.5 h-3.5 text-muted-foreground" />
          </button>
          <button
            onClick={() => navigate(`/datasets/${row.id}?tab=analysis`)}
            className="p-1.5 rounded hover:bg-muted transition-colors" title="Analyze"
          >
            <BarChart2 className="w-3.5 h-3.5 text-muted-foreground" />
          </button>
          <button
            onClick={() => setDeleteTarget(row)}
            className="p-1.5 rounded hover:bg-red-500/10 hover:text-red-500 transition-colors" title="Delete"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      ),
    },
  ];

  return (
    <div className="flex flex-col h-full overflow-hidden">
      <PageHeader
        title="Datasets"
        breadcrumbs={[{ label: 'Dashboard', href: '/dashboard' }, { label: 'Datasets' }]}
        description="Manage your training datasets. Upload CSV files and analyze their structure."
        actions={
          <button
            onClick={() => setUploadOpen(true)}
            className="flex items-center gap-1.5 h-8 px-3 rounded-md text-sm bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" /> Upload Dataset
          </button>
        }
      />

      <div className="flex-1 overflow-y-auto">
        <div className="p-6 space-y-4">
          {/* Toolbar */}
          <div className="flex items-center gap-3">
            <SearchBox
              value={search}
              onChange={(v) => { setSearch(v); setPage(1); }}
              placeholder="Search datasets…"
              className="w-64"
            />
            {data && (
              <span className="text-xs text-muted-foreground ml-auto">{data.total} dataset{data.total !== 1 ? 's' : ''}</span>
            )}
          </div>

          {/* Table */}
          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <DataTable
              columns={columns}
              data={data?.items ?? []}
              loading={isLoading}
              rowKey={(r) => r.id}
              onRowClick={(r) => navigate(`/datasets/${r.id}`)}
              emptyMessage="No datasets found"
              emptyDescription="Upload a CSV file to get started"
              emptyIcon={<Database className="w-6 h-6 text-muted-foreground" />}
            />
            {data && data.pages > 1 && (
              <Pagination
                page={data.page}
                pages={data.pages}
                total={data.total}
                pageSize={DEFAULT_PAGE_SIZE}
                onPageChange={setPage}
              />
            )}
          </div>
        </div>
      </div>

      {/* Upload Dialog */}
      <UploadDialog open={uploadOpen} onClose={() => setUploadOpen(false)} />

      {/* Delete confirm */}
      <ConfirmationDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={() => deleteTarget && deleteMutation.mutate(deleteTarget.id)}
        title="Delete Dataset"
        description={`Are you sure you want to delete "${deleteTarget?.name}"? This action cannot be undone.`}
        confirmLabel="Delete"
        danger
        loading={deleteMutation.isPending}
      />
    </div>
  );
}

function UploadDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const queryClient = useQueryClient();
  const [file, setFile] = useState<File | null>(null);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [progress, setProgress] = useState(0);
  const [uploading, setUploading] = useState(false);

  const onDrop = useCallback((accepted: File[]) => {
    const f = accepted[0];
    if (f) { setFile(f); setName(f.name.replace(/\.[^.]+$/, '')); }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop, accept: { 'text/csv': ['.csv'], 'application/vnd.ms-excel': ['.csv'] }, maxFiles: 1,
  });

  const handleUpload = async () => {
    if (!file || !name.trim()) return;
    setUploading(true);
    setProgress(0);
    try {
      await datasetService.upload(file, name, description || undefined, setProgress);
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.datasets });
      toast.success('Dataset uploaded successfully');
      onClose();
      setFile(null); setName(''); setDescription('');
    } catch {
      toast.error('Upload failed. Please try again.');
    } finally {
      setUploading(false); setProgress(0);
    }
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 8 }}
            onClick={e => e.stopPropagation()}
            className="bg-card border border-border rounded-xl p-6 w-full max-w-lg shadow-2xl"
          >
            <div className="flex items-center justify-between mb-5">
              <h3 className="font-semibold">Upload Dataset</h3>
              <button onClick={onClose} className="p-1 rounded hover:bg-muted transition-colors">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Dropzone */}
            <div
              {...getRootProps()}
              className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-colors ${
                isDragActive ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/50 hover:bg-muted/30'
              }`}
            >
              <input {...getInputProps()} />
              {file ? (
                <div className="flex items-center justify-center gap-3">
                  <FileText className="w-8 h-8 text-emerald-500" />
                  <div className="text-left">
                    <p className="text-sm font-medium">{file.name}</p>
                    <p className="text-xs text-muted-foreground">{formatBytes(file.size)}</p>
                  </div>
                  <button
                    onClick={e => { e.stopPropagation(); setFile(null); setName(''); }}
                    className="p-1 rounded hover:bg-red-500/10 hover:text-red-500 transition-colors ml-2"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <>
                  <Upload className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
                  <p className="text-sm font-medium">Drop CSV file here or click to browse</p>
                  <p className="text-xs text-muted-foreground mt-1">Supports .csv files up to 500 MB</p>
                </>
              )}
            </div>

            {/* Fields */}
            <div className="space-y-3 mt-4">
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Dataset Name *</label>
                <input
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full h-9 px-3 rounded-md border border-border bg-input-background text-sm focus:outline-none focus:ring-1 focus:ring-ring"
                  placeholder="my-dataset"
                />
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block">Description</label>
                <textarea
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  rows={2}
                  className="w-full px-3 py-2 rounded-md border border-border bg-input-background text-sm focus:outline-none focus:ring-1 focus:ring-ring resize-none"
                  placeholder="Optional description…"
                />
              </div>
            </div>

            {uploading && (
              <div className="mt-4 space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">Uploading…</span>
                  <span className="font-mono">{progress}%</span>
                </div>
                <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${progress}%` }} />
                </div>
              </div>
            )}

            <div className="flex justify-end gap-3 mt-5">
              <button onClick={onClose} disabled={uploading} className="px-4 py-2 rounded-md text-sm border border-border hover:bg-muted transition-colors">
                Cancel
              </button>
              <button
                onClick={handleUpload}
                disabled={!file || !name.trim() || uploading}
                className="px-4 py-2 rounded-md text-sm bg-primary text-primary-foreground hover:bg-primary/90 transition-colors flex items-center gap-2 disabled:opacity-50"
              >
                {uploading ? <><Loader2 className="w-3.5 h-3.5 animate-spin" /> Uploading…</> : <><Upload className="w-3.5 h-3.5" /> Upload</>}
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
