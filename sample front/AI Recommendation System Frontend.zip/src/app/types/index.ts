// ─── Auth ────────────────────────────────────────────────────────────────────
export type UserRole = 'ADMIN' | 'USER';

export interface User {
  id: string;
  username: string;
  email: string;
  full_name?: string;
  role: UserRole;
  is_active: boolean;
  created_at: string;
  last_login?: string;
  avatar?: string;
}

export interface LoginRequest { username: string; password: string; }
export interface AuthTokens {
  access_token: string;
  refresh_token: string;
  token_type: string;
  expires_in: number;
}
export interface LoginResponse extends AuthTokens { user: User; }

// ─── Datasets ─────────────────────────────────────────────────────────────────
export type DatasetStatus = 'PENDING' | 'PROCESSING' | 'READY' | 'ERROR';

export interface Dataset {
  id: string;
  name: string;
  description?: string;
  filename: string;
  file_size: number;
  row_count?: number;
  column_count?: number;
  status: DatasetStatus;
  created_at: string;
  updated_at: string;
  created_by: string;
  tags?: string[];
}

export interface DatasetPreview {
  columns: string[];
  rows: Record<string, unknown>[];
  total_rows: number;
  page: number;
  page_size: number;
}

export interface ColumnStats {
  name: string;
  dtype: string;
  null_count: number;
  unique_count: number;
  min?: number | string;
  max?: number | string;
  mean?: number;
  std?: number;
  top_values?: { value: string; count: number }[];
}

export interface DatasetAnalysis {
  dataset_id: string;
  row_count: number;
  column_count: number;
  columns: ColumnStats[];
  missing_percentage: number;
  memory_usage_mb: number;
  analyzed_at: string;
}

// ─── Training ─────────────────────────────────────────────────────────────────
export type JobStatus = 'PENDING' | 'RUNNING' | 'COMPLETED' | 'FAILED' | 'CANCELLED';
export type TrainingStrategy = 'collaborative_filtering' | 'content_based' | 'hybrid' | 'neural';

export interface TrainingConfig {
  strategy: TrainingStrategy;
  epochs: number;
  learning_rate: number;
  batch_size: number;
  hidden_dims?: number[];
  auto_configure: boolean;
  context_columns?: string[];
  user_column?: string;
  item_column?: string;
  rating_column?: string;
}

export interface TrainingJob {
  id: string;
  name: string;
  dataset_id: string;
  dataset_name: string;
  config: TrainingConfig;
  status: JobStatus;
  progress: number;
  current_epoch: number;
  total_epochs: number;
  current_loss?: number;
  best_loss?: number;
  eta_seconds?: number;
  started_at?: string;
  completed_at?: string;
  created_at: string;
  created_by: string;
  model_id?: string;
  error_message?: string;
}

export interface TrainingProgress {
  job_id: string;
  status: JobStatus;
  progress: number;
  current_epoch: number;
  total_epochs: number;
  current_loss?: number;
  best_loss?: number;
  eta_seconds?: number;
  logs: string[];
}

export interface EpochMetrics {
  epoch: number;
  loss: number;
  val_loss?: number;
  accuracy?: number;
  val_accuracy?: number;
  timestamp: string;
}

// ─── Models ───────────────────────────────────────────────────────────────────
export interface ModelMetrics {
  precision?: number;
  recall?: number;
  f1_score?: number;
  ndcg?: number;
  map?: number;
  rmse?: number;
  mae?: number;
}

export interface Model {
  id: string;
  name: string;
  description?: string;
  strategy: TrainingStrategy;
  version: string;
  metrics: ModelMetrics;
  training_job_id: string;
  dataset_id: string;
  dataset_name: string;
  file_size_mb: number;
  is_active: boolean;
  created_at: string;
  created_by: string;
  tags?: string[];
}

export interface AvailableModel {
  id: string;
  name: string;
  strategy: TrainingStrategy;
  metrics: ModelMetrics;
  is_active: boolean;
}

// ─── Inference ────────────────────────────────────────────────────────────────
export interface RecommendationRequest {
  model_id: string;
  user_id: string;
  top_k?: number;
  context?: Record<string, unknown>;
}

export interface RecommendationItem {
  item_id: string;
  score: number;
  rank: number;
  explanation?: string;
  metadata?: Record<string, unknown>;
}

export interface RecommendationResponse {
  user_id: string;
  model_id: string;
  recommendations: RecommendationItem[];
  inference_time_ms: number;
  generated_at: string;
}

export interface PredictionRequest {
  model_id: string;
  user_id: string;
  item_id: string;
  context?: Record<string, unknown>;
}

export interface PredictionResponse {
  user_id: string;
  item_id: string;
  score: number;
  explanation?: string;
  inference_time_ms: number;
}

export interface ScenarioRequest {
  model_id: string;
  scenarios: { user_id: string; item_id: string; context?: Record<string, unknown> }[];
}

export interface ScenarioResponse {
  results: (PredictionResponse & { scenario_index: number })[];
  total_inference_time_ms: number;
}

// ─── Admin ────────────────────────────────────────────────────────────────────
export interface CreateUserRequest {
  username: string;
  email: string;
  password: string;
  full_name?: string;
  role: UserRole;
}

export interface AuditLog {
  id: string;
  user_id: string;
  username: string;
  action: string;
  resource_type: string;
  resource_id?: string;
  details?: Record<string, unknown>;
  ip_address?: string;
  user_agent?: string;
  timestamp: string;
  success: boolean;
}

export interface OnlineUser {
  user_id: string;
  username: string;
  role: UserRole;
  connected_at: string;
  last_activity: string;
  ip_address?: string;
}

// ─── Monitoring ───────────────────────────────────────────────────────────────
export interface SystemMetrics {
  cpu_percent: number;
  memory_percent: number;
  memory_used_gb: number;
  memory_total_gb: number;
  disk_percent: number;
  disk_used_gb: number;
  disk_total_gb: number;
  gpu_percent?: number;
  network_rx_mbps?: number;
  network_tx_mbps?: number;
  timestamp: string;
}

export interface SystemSnapshot {
  metrics: SystemMetrics;
  active_jobs: number;
  pending_jobs: number;
  total_models: number;
  total_datasets: number;
  online_users: number;
  uptime_seconds: number;
}

export interface QueueStatus {
  pending: number;
  running: number;
  completed_today: number;
  failed_today: number;
  avg_wait_time_seconds: number;
}

export interface UploadStatus {
  id: string;
  filename: string;
  status: 'uploading' | 'processing' | 'done' | 'error';
  progress: number;
  size_mb: number;
  started_at: string;
}

// ─── Common ───────────────────────────────────────────────────────────────────
export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  page_size: number;
  pages: number;
}

export interface ApiError {
  detail: string;
  status_code?: number;
  errors?: Record<string, string[]>;
}

export interface Notification {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message: string;
  read: boolean;
  created_at: string;
  link?: string;
}

export interface BreadcrumbItem { label: string; href?: string; }

export interface FilterOption { label: string; value: string; }
