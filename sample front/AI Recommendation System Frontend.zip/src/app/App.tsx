import { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

import { useThemeStore } from './store/themeStore';
import { useAuthStore } from './store/authStore';
import { useNotificationStore } from './store/notificationStore';

import { AppLayout } from './components/layout/AppLayout';
import { ProtectedRoute } from './components/layout/ProtectedRoute';

import { LoginPage } from './pages/auth/LoginPage';
import { DashboardPage } from './pages/dashboard/DashboardPage';
import { DatasetsPage } from './pages/datasets/DatasetsPage';
import { DatasetDetailPage } from './pages/datasets/DatasetDetailPage';
import { TrainingPage } from './pages/training/TrainingPage';
import { TrainingDetailPage } from './pages/training/TrainingDetailPage';
import { ModelsPage } from './pages/models/ModelsPage';
import { ModelDetailPage } from './pages/models/ModelDetailPage';
import { InferencePage } from './pages/inference/InferencePage';
import { AdminPage } from './pages/admin/AdminPage';
import { MonitoringPage } from './pages/monitoring/MonitoringPage';
import { SettingsPage } from './pages/settings/SettingsPage';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30_000,
      retry: (failureCount, error: unknown) => {
        const status = (error as { response?: { status?: number } })?.response?.status;
        if (status === 401 || status === 403 || status === 404) return false;
        return failureCount < 2;
      },
    },
  },
});

export default function App() {
  const { theme } = useThemeStore();
  const { logout, isAuthenticated } = useAuthStore();
  const { addNotification, notifications } = useNotificationStore();

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') root.classList.add('dark');
    else if (theme === 'light') root.classList.remove('dark');
    else {
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      prefersDark ? root.classList.add('dark') : root.classList.remove('dark');
    }
  }, [theme]);

  useEffect(() => {
    const handler = () => logout();
    window.addEventListener('auth:logout', handler);
    return () => window.removeEventListener('auth:logout', handler);
  }, [logout]);

  // Seed initial notifications on first login
  useEffect(() => {
    if (isAuthenticated && notifications.length === 0) {
      addNotification({ type: 'success', title: 'Training Complete', message: 'MovieLens CF v3 finished training with 82.3% precision.' });
      addNotification({ type: 'info', title: 'New Dataset Ready', message: 'Amazon Reviews Electronics dataset processed successfully.' });
      addNotification({ type: 'warning', title: 'High Memory Usage', message: 'System memory usage exceeded 80%. Consider scaling resources.' });
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAuthenticated]);

  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/" element={<Navigate to="/dashboard" replace />} />

          <Route element={<ProtectedRoute />}>
            <Route element={<AppLayout />}>
              <Route path="/dashboard" element={<DashboardPage />} />

              <Route path="/datasets" element={<DatasetsPage />} />
              <Route path="/datasets/:id" element={<DatasetDetailPage />} />

              <Route path="/training" element={<TrainingPage />} />
              <Route path="/training/:id" element={<TrainingDetailPage />} />

              <Route path="/models" element={<ModelsPage />} />
              <Route path="/models/:id" element={<ModelDetailPage />} />

              <Route path="/inference" element={<InferencePage />} />
              <Route path="/settings" element={<SettingsPage />} />

              <Route element={<ProtectedRoute requiredRole="ADMIN" />}>
                <Route path="/admin" element={<AdminPage />} />
                <Route path="/monitoring" element={<MonitoringPage />} />
              </Route>
            </Route>
          </Route>

          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Routes>
      </BrowserRouter>
    </QueryClientProvider>
  );
}
