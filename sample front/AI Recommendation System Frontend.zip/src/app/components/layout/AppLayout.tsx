import { Outlet } from 'react-router';
import { Toaster } from 'sonner';
import { Sidebar } from './Sidebar';

export function AppLayout() {
  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <Sidebar />
      <main className="flex-1 flex flex-col overflow-hidden min-w-0">
        <Outlet />
      </main>
      <Toaster
        position="bottom-right"
        toastOptions={{
          style: { background: 'var(--card)', border: '1px solid var(--border)', color: 'var(--foreground)' },
        }}
      />
    </div>
  );
}
