import { NavLink, useLocation } from 'react-router';
import { motion, AnimatePresence } from 'motion/react';
import {
  LayoutDashboard, Database, Cpu, BrainCircuit, Zap,
  ShieldCheck, Activity, Settings, ChevronLeft, ChevronRight,
  Sparkles, LogOut, User
} from 'lucide-react';
import { cn } from '../../lib/utils';
import { useThemeStore } from '../../store/themeStore';
import { useAuthStore } from '../../store/authStore';

const NAV_ITEMS = [
  { label: 'Dashboard', icon: LayoutDashboard, href: '/dashboard' },
  { label: 'Datasets', icon: Database, href: '/datasets' },
  { label: 'Training', icon: Cpu, href: '/training' },
  { label: 'Models', icon: BrainCircuit, href: '/models' },
  { label: 'Inference', icon: Zap, href: '/inference' },
] as const;

const ADMIN_ITEMS = [
  { label: 'Administration', icon: ShieldCheck, href: '/admin' },
  { label: 'Monitoring', icon: Activity, href: '/monitoring' },
] as const;

const BOTTOM_ITEMS = [
  { label: 'Settings', icon: Settings, href: '/settings' },
] as const;

interface SidebarProps { className?: string; }

export function Sidebar({ className }: SidebarProps) {
  const { sidebarCollapsed, toggleSidebar } = useThemeStore();
  const { user, logout } = useAuthStore();
  const location = useLocation();

  return (
    <motion.aside
      animate={{ width: sidebarCollapsed ? 64 : 220 }}
      transition={{ duration: 0.2, ease: 'easeInOut' }}
      className={cn(
        'relative flex flex-col h-full bg-sidebar border-r border-sidebar-border overflow-hidden shrink-0',
        className
      )}
    >
      {/* Logo */}
      <div className="flex items-center h-14 px-3 border-b border-sidebar-border shrink-0">
        <div className="flex items-center gap-2 min-w-0">
          <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
            <Sparkles className="w-4 h-4 text-primary" />
          </div>
          <AnimatePresence>
            {!sidebarCollapsed && (
              <motion.span
                initial={{ opacity: 0, width: 0 }}
                animate={{ opacity: 1, width: 'auto' }}
                exit={{ opacity: 0, width: 0 }}
                transition={{ duration: 0.15 }}
                className="overflow-hidden whitespace-nowrap text-sidebar-foreground font-semibold text-sm"
              >
                AI Rec System
              </motion.span>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 py-3 overflow-y-auto overflow-x-hidden">
        <NavSection items={NAV_ITEMS} collapsed={sidebarCollapsed} location={location.pathname} />

        <div className="mx-3 my-2 border-t border-sidebar-border" />

        {user?.role === 'ADMIN' && (
          <NavSection items={ADMIN_ITEMS} collapsed={sidebarCollapsed} location={location.pathname} />
        )}
      </nav>

      {/* Bottom */}
      <div className="pb-3 border-t border-sidebar-border pt-3">
        <NavSection items={BOTTOM_ITEMS} collapsed={sidebarCollapsed} location={location.pathname} />

        {/* User */}
        <div className={cn(
          'flex items-center gap-2 mx-2 px-2 py-2 rounded-md hover:bg-sidebar-accent cursor-pointer transition-colors mt-1',
          sidebarCollapsed && 'justify-center'
        )}>
          <div className="w-7 h-7 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
            <User className="w-3.5 h-3.5 text-primary" />
          </div>
          <AnimatePresence>
            {!sidebarCollapsed && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex-1 min-w-0"
              >
                <p className="text-xs font-medium text-sidebar-foreground truncate">{user?.full_name || user?.username}</p>
                <p className="text-xs text-muted-foreground truncate">{user?.role}</p>
              </motion.div>
            )}
          </AnimatePresence>
          {!sidebarCollapsed && (
            <button
              onClick={logout}
              className="p-1 rounded hover:bg-destructive/10 hover:text-destructive transition-colors"
              title="Logout"
            >
              <LogOut className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Collapse toggle */}
      <button
        onClick={toggleSidebar}
        className="absolute -right-3 top-16 w-6 h-6 rounded-full bg-background border border-border flex items-center justify-center shadow-sm hover:bg-muted transition-colors z-10"
      >
        {sidebarCollapsed ? <ChevronRight className="w-3 h-3" /> : <ChevronLeft className="w-3 h-3" />}
      </button>
    </motion.aside>
  );
}

function NavSection({
  items, collapsed, location,
}: {
  items: readonly { label: string; icon: React.ComponentType<{ className?: string }>; href: string }[];
  collapsed: boolean;
  location: string;
}) {
  return (
    <ul className="space-y-0.5 px-2">
      {items.map(({ label, icon: Icon, href }) => {
        const active = location.startsWith(href);
        return (
          <li key={href}>
            <NavLink
              to={href}
              title={collapsed ? label : undefined}
              className={cn(
                'flex items-center gap-2.5 px-2 py-2 rounded-md text-sm transition-colors',
                active
                  ? 'bg-sidebar-primary/10 text-sidebar-primary font-medium'
                  : 'text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground',
                collapsed && 'justify-center'
              )}
            >
              <Icon className={cn('w-4 h-4 shrink-0', active && 'text-sidebar-primary')} />
              <AnimatePresence>
                {!collapsed && (
                  <motion.span
                    initial={{ opacity: 0, width: 0 }}
                    animate={{ opacity: 1, width: 'auto' }}
                    exit={{ opacity: 0, width: 0 }}
                    transition={{ duration: 0.15 }}
                    className="overflow-hidden whitespace-nowrap"
                  >
                    {label}
                  </motion.span>
                )}
              </AnimatePresence>
            </NavLink>
          </li>
        );
      })}
    </ul>
  );
}
