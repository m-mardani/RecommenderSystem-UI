import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { Bell, Sun, Moon, Search, Command, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn, formatRelativeTime } from '../../lib/utils';
import { useThemeStore } from '../../store/themeStore';
import { useNotificationStore } from '../../store/notificationStore';
import { BreadcrumbItem } from '../../types';

interface TopNavProps {
  breadcrumbs?: BreadcrumbItem[];
  title?: string;
  actions?: React.ReactNode;
}

export function TopNav({ breadcrumbs, title, actions }: TopNavProps) {
  const { theme, setTheme } = useThemeStore();
  const { notifications, unreadCount, markRead, markAllRead } = useNotificationStore();
  const [notifOpen, setNotifOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const notifRef = useRef<HTMLDivElement>(null);
  const searchRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setNotifOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  useEffect(() => {
    function handleKey(e: KeyboardEvent) {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setSearchOpen(true);
        setTimeout(() => searchRef.current?.focus(), 50);
      }
      if (e.key === 'Escape') setSearchOpen(false);
    }
    document.addEventListener('keydown', handleKey);
    return () => document.removeEventListener('keydown', handleKey);
  }, []);

  const SEARCH_SHORTCUTS = [
    { label: 'Dashboard', href: '/dashboard', hint: 'Overview & KPIs' },
    { label: 'Datasets', href: '/datasets', hint: 'Manage data' },
    { label: 'Training', href: '/training', hint: 'Train models' },
    { label: 'Models', href: '/models', hint: 'Trained models' },
    { label: 'Inference', href: '/inference', hint: 'Run predictions' },
    { label: 'Monitoring', href: '/monitoring', hint: 'System health' },
    { label: 'Settings', href: '/settings', hint: 'Preferences' },
  ].filter(s => !searchQuery || s.label.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <header className="h-14 border-b border-border bg-background/80 backdrop-blur-sm sticky top-0 z-20 flex items-center px-4 gap-3">
      {/* Breadcrumbs / Title */}
      <div className="flex-1 min-w-0">
        {breadcrumbs && breadcrumbs.length > 0 ? (
          <nav className="flex items-center gap-1.5 text-sm">
            {breadcrumbs.map((b, i) => (
              <span key={i} className="flex items-center gap-1.5">
                {i > 0 && <span className="text-muted-foreground">/</span>}
                {b.href ? (
                  <button
                    onClick={() => navigate(b.href!)}
                    className="text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {b.label}
                  </button>
                ) : (
                  <span className="text-foreground font-medium">{b.label}</span>
                )}
              </span>
            ))}
          </nav>
        ) : title ? (
          <h1 className="font-semibold text-foreground truncate">{title}</h1>
        ) : null}
      </div>

      {/* Actions */}
      {actions && <div className="flex items-center gap-2">{actions}</div>}

      {/* Search */}
      <button
        onClick={() => { setSearchOpen(true); setTimeout(() => searchRef.current?.focus(), 50); }}
        className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-muted text-muted-foreground text-sm hover:bg-muted/80 transition-colors"
      >
        <Search className="w-3.5 h-3.5" />
        <span className="hidden sm:block">Search…</span>
        <kbd className="hidden sm:flex items-center gap-0.5 text-xs bg-background border border-border rounded px-1">
          <Command className="w-2.5 h-2.5" />K
        </kbd>
      </button>

      {/* Theme toggle */}
      <button
        onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
        className="w-8 h-8 rounded-md hover:bg-muted flex items-center justify-center transition-colors"
        title="Toggle theme"
      >
        {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
      </button>

      {/* Notifications */}
      <div ref={notifRef} className="relative">
        <button
          onClick={() => setNotifOpen(!notifOpen)}
          className="w-8 h-8 rounded-md hover:bg-muted flex items-center justify-center transition-colors relative"
        >
          <Bell className="w-4 h-4" />
          {unreadCount > 0 && (
            <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-primary text-primary-foreground text-[10px] font-bold flex items-center justify-center">
              {unreadCount > 9 ? '9+' : unreadCount}
            </span>
          )}
        </button>

        <AnimatePresence>
          {notifOpen && (
            <motion.div
              initial={{ opacity: 0, y: -8, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -8, scale: 0.95 }}
              transition={{ duration: 0.15 }}
              className="absolute right-0 top-10 w-80 bg-card border border-border rounded-xl shadow-xl z-50 overflow-hidden"
            >
              <div className="flex items-center justify-between px-4 py-3 border-b border-border">
                <span className="font-medium text-sm">Notifications</span>
                {unreadCount > 0 && (
                  <button onClick={markAllRead} className="text-xs text-primary hover:underline">
                    Mark all read
                  </button>
                )}
              </div>
              <div className="max-h-80 overflow-y-auto">
                {notifications.length === 0 ? (
                  <div className="p-6 text-center text-sm text-muted-foreground">No notifications</div>
                ) : (
                  notifications.slice(0, 10).map(n => (
                    <div
                      key={n.id}
                      onClick={() => markRead(n.id)}
                      className={cn(
                        'px-4 py-3 border-b border-border/50 cursor-pointer hover:bg-muted/50 transition-colors',
                        !n.read && 'bg-primary/5'
                      )}
                    >
                      <div className="flex items-start gap-2">
                        <div className={cn('w-2 h-2 rounded-full mt-1.5 shrink-0', {
                          'bg-emerald-500': n.type === 'success',
                          'bg-red-500': n.type === 'error',
                          'bg-amber-500': n.type === 'warning',
                          'bg-sky-500': n.type === 'info',
                        })} />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{n.title}</p>
                          <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{n.message}</p>
                          <p className="text-xs text-muted-foreground/70 mt-1">{formatRelativeTime(n.created_at)}</p>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Search Modal */}
      <AnimatePresence>
        {searchOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-50 flex items-start justify-center pt-24"
            onClick={() => setSearchOpen(false)}
          >
            <motion.div
              initial={{ opacity: 0, y: -16, scale: 0.97 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -16, scale: 0.97 }}
              transition={{ duration: 0.15 }}
              onClick={e => e.stopPropagation()}
              className="w-full max-w-lg bg-card border border-border rounded-xl shadow-2xl overflow-hidden"
            >
              <div className="flex items-center gap-3 px-4 py-3 border-b border-border">
                <Search className="w-4 h-4 text-muted-foreground" />
                <input
                  ref={searchRef}
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  placeholder="Search pages, actions…"
                  className="flex-1 bg-transparent text-sm outline-none text-foreground placeholder:text-muted-foreground"
                />
                <button onClick={() => setSearchOpen(false)}>
                  <X className="w-4 h-4 text-muted-foreground" />
                </button>
              </div>
              <div className="p-2 max-h-64 overflow-y-auto">
                {SEARCH_SHORTCUTS.map(s => (
                  <button
                    key={s.href}
                    onClick={() => { navigate(s.href); setSearchOpen(false); setSearchQuery(''); }}
                    className="w-full flex items-center justify-between px-3 py-2 rounded-md hover:bg-muted transition-colors text-left"
                  >
                    <span className="text-sm font-medium">{s.label}</span>
                    <span className="text-xs text-muted-foreground">{s.hint}</span>
                  </button>
                ))}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
