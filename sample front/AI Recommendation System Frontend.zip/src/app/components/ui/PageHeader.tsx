import { ReactNode } from 'react';
import { TopNav } from '../layout/TopNav';
import { BreadcrumbItem } from '../../types';

interface PageHeaderProps {
  title: string;
  breadcrumbs?: BreadcrumbItem[];
  description?: string;
  actions?: ReactNode;
  children?: ReactNode;
}

export function PageHeader({ title, breadcrumbs, description, actions, children }: PageHeaderProps) {
  return (
    <>
      <TopNav breadcrumbs={breadcrumbs} title={!breadcrumbs ? title : undefined} actions={actions} />
      {(description || children) && (
        <div className="px-6 pt-6 pb-2">
          {description && <p className="text-sm text-muted-foreground">{description}</p>}
          {children}
        </div>
      )}
    </>
  );
}
