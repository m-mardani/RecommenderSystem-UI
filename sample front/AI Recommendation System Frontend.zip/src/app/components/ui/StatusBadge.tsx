import { cn, getStatusBg } from '../../lib/utils';

interface StatusBadgeProps {
  status: string;
  size?: 'sm' | 'md';
  dot?: boolean;
}

export function StatusBadge({ status, size = 'md', dot = true }: StatusBadgeProps) {
  return (
    <span className={cn(
      'inline-flex items-center gap-1.5 rounded-full font-medium',
      size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-2.5 py-1 text-xs',
      getStatusBg(status)
    )}>
      {dot && <span className="w-1.5 h-1.5 rounded-full bg-current" />}
      {status}
    </span>
  );
}

interface RoleBadgeProps { role: 'ADMIN' | 'USER'; }

export function RoleBadge({ role }: RoleBadgeProps) {
  return (
    <span className={cn(
      'inline-flex items-center px-2 py-0.5 rounded text-xs font-medium',
      role === 'ADMIN' ? 'bg-violet-500/10 text-violet-500' : 'bg-sky-500/10 text-sky-500'
    )}>
      {role}
    </span>
  );
}
