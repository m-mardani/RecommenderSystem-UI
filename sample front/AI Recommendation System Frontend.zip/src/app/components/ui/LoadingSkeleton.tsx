import { cn } from '../../lib/utils';

interface LoadingSkeletonProps {
  rows?: number;
  className?: string;
}

export function LoadingSkeleton({ rows = 5, className }: LoadingSkeletonProps) {
  return (
    <div className={cn('space-y-3 p-4', className)}>
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="flex items-center gap-4">
          <div className="h-4 rounded skeleton-shimmer" style={{ width: `${30 + (i * 13) % 40}%` }} />
          <div className="h-4 rounded skeleton-shimmer flex-1" />
          <div className="h-4 w-16 rounded skeleton-shimmer" />
        </div>
      ))}
    </div>
  );
}

export function CardSkeleton({ className }: { className?: string }) {
  return (
    <div className={cn('bg-card border border-border rounded-xl p-4 space-y-3', className)}>
      <div className="flex items-center justify-between">
        <div className="h-4 w-24 rounded skeleton-shimmer" />
        <div className="h-8 w-8 rounded-lg skeleton-shimmer" />
      </div>
      <div className="h-8 w-20 rounded skeleton-shimmer" />
      <div className="h-3 w-32 rounded skeleton-shimmer" />
    </div>
  );
}

export function PageSkeleton() {
  return (
    <div className="p-6 space-y-6">
      <div className="h-8 w-48 rounded skeleton-shimmer" />
      <div className="grid grid-cols-4 gap-4">
        {[0, 1, 2, 3].map(i => <CardSkeleton key={i} />)}
      </div>
      <div className="bg-card border border-border rounded-xl">
        <LoadingSkeleton rows={8} />
      </div>
    </div>
  );
}
