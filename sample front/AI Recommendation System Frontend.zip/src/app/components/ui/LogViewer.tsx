import { useEffect, useRef } from 'react';
import { Terminal } from 'lucide-react';
import { cn } from '../../lib/utils';

interface LogViewerProps {
  logs: string[];
  autoScroll?: boolean;
  maxHeight?: string;
  className?: string;
}

export function LogViewer({ logs, autoScroll = true, maxHeight = '300px', className }: LogViewerProps) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (autoScroll && ref.current) {
      ref.current.scrollTop = ref.current.scrollHeight;
    }
  }, [logs, autoScroll]);

  const getLogClass = (line: string) => {
    if (line.includes('ERROR') || line.includes('error')) return 'text-red-400';
    if (line.includes('WARN') || line.includes('warning')) return 'text-amber-400';
    if (line.includes('SUCCESS') || line.includes('Epoch') || line.includes('loss')) return 'text-emerald-400';
    if (line.includes('INFO') || line.includes('Starting')) return 'text-sky-400';
    return 'text-zinc-300';
  };

  return (
    <div className={cn('bg-zinc-950 rounded-lg border border-zinc-800 overflow-hidden', className)}>
      <div className="flex items-center gap-2 px-3 py-2 border-b border-zinc-800 bg-zinc-900">
        <Terminal className="w-3.5 h-3.5 text-zinc-500" />
        <span className="text-xs text-zinc-500 font-mono">{logs.length} lines</span>
      </div>
      <div
        ref={ref}
        className="p-3 overflow-y-auto font-mono text-xs leading-relaxed"
        style={{ maxHeight }}
      >
        {logs.length === 0 ? (
          <p className="text-zinc-600">Waiting for logs…</p>
        ) : (
          logs.map((line, i) => (
            <div key={i} className={cn('py-0.5', getLogClass(line))}>
              <span className="text-zinc-600 select-none mr-3">{String(i + 1).padStart(3, '0')}</span>
              {line}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
