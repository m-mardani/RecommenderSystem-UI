import { ReactNode } from 'react';
import { cn } from '../../lib/utils';
import { Inbox } from 'lucide-react';

interface EmptyStateProps {
  message?: string;
  description?: string;
  icon?: ReactNode;
  action?: ReactNode;
  className?: string;
}

export function EmptyState({ message = 'No data found', description, icon, action, className }: EmptyStateProps) {
  return (
    <div className={cn('flex flex-col items-center justify-center gap-3 py-8 text-center', className)}>
      <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center">
        {icon ?? <Inbox className="w-6 h-6 text-muted-foreground" />}
      </div>
      <div>
        <p className="text-sm font-medium text-foreground">{message}</p>
        {description && <p className="text-xs text-muted-foreground mt-1">{description}</p>}
      </div>
      {action && <div className="mt-2">{action}</div>}
    </div>
  );
}
