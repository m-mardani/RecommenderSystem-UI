import { ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight } from 'lucide-react';
import { cn } from '../../lib/utils';

interface PaginationProps {
  page: number;
  pages: number;
  total: number;
  pageSize: number;
  onPageChange: (page: number) => void;
  className?: string;
}

export function Pagination({ page, pages, total, pageSize, onPageChange, className }: PaginationProps) {
  const start = Math.min((page - 1) * pageSize + 1, total);
  const end = Math.min(page * pageSize, total);

  const range = (start: number, end: number) =>
    Array.from({ length: end - start + 1 }, (_, i) => start + i);

  let pageNumbers: (number | '...')[] = [];
  if (pages <= 7) {
    pageNumbers = range(1, pages);
  } else if (page <= 4) {
    pageNumbers = [...range(1, 5), '...', pages];
  } else if (page >= pages - 3) {
    pageNumbers = [1, '...', ...range(pages - 4, pages)];
  } else {
    pageNumbers = [1, '...', ...range(page - 1, page + 1), '...', pages];
  }

  return (
    <div className={cn('flex items-center justify-between px-4 py-3 border-t border-border', className)}>
      <span className="text-xs text-muted-foreground">
        Showing {start}–{end} of {total}
      </span>
      <div className="flex items-center gap-1">
        <PagBtn onClick={() => onPageChange(1)} disabled={page === 1} title="First">
          <ChevronsLeft className="w-3 h-3" />
        </PagBtn>
        <PagBtn onClick={() => onPageChange(page - 1)} disabled={page === 1} title="Previous">
          <ChevronLeft className="w-3 h-3" />
        </PagBtn>
        {pageNumbers.map((p, i) =>
          p === '...' ? (
            <span key={`ellipsis-${i}`} className="px-2 text-muted-foreground text-xs">…</span>
          ) : (
            <PagBtn key={p} onClick={() => onPageChange(p as number)} active={p === page}>
              {p}
            </PagBtn>
          )
        )}
        <PagBtn onClick={() => onPageChange(page + 1)} disabled={page === pages} title="Next">
          <ChevronRight className="w-3 h-3" />
        </PagBtn>
        <PagBtn onClick={() => onPageChange(pages)} disabled={page === pages} title="Last">
          <ChevronsRight className="w-3 h-3" />
        </PagBtn>
      </div>
    </div>
  );
}

function PagBtn({
  children, onClick, disabled, active, title,
}: {
  children: React.ReactNode;
  onClick: () => void;
  disabled?: boolean;
  active?: boolean;
  title?: string;
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      title={title}
      className={cn(
        'w-7 h-7 rounded text-xs flex items-center justify-center transition-colors',
        active ? 'bg-primary text-primary-foreground' : 'hover:bg-muted text-foreground',
        disabled && 'opacity-40 pointer-events-none'
      )}
    >
      {children}
    </button>
  );
}
