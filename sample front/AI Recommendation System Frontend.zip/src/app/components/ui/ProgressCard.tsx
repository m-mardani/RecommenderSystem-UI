import { cn } from '../../lib/utils';
import { formatDuration } from '../../lib/utils';

interface ProgressCardProps {
  label: string;
  value: number;
  max?: number;
  unit?: string;
  eta?: number;
  color?: 'blue' | 'purple' | 'emerald' | 'amber' | 'red';
  size?: 'sm' | 'md';
  showPercentage?: boolean;
  className?: string;
}

const COLOR_CLASSES = {
  blue: 'bg-sky-500',
  purple: 'bg-violet-500',
  emerald: 'bg-emerald-500',
  amber: 'bg-amber-500',
  red: 'bg-red-500',
};

export function ProgressCard({
  label, value, max = 100, unit, eta, color = 'blue', size = 'md', showPercentage = true, className,
}: ProgressCardProps) {
  const pct = Math.min(100, Math.round((value / max) * 100));

  return (
    <div className={cn('space-y-1.5', className)}>
      <div className="flex items-center justify-between">
        <span className={cn('text-muted-foreground', size === 'sm' ? 'text-xs' : 'text-sm')}>{label}</span>
        <div className="flex items-center gap-2">
          {showPercentage && (
            <span className={cn('font-medium', size === 'sm' ? 'text-xs' : 'text-sm')}>
              {unit ? `${value}${unit}` : `${pct}%`}
            </span>
          )}
          {eta != null && eta > 0 && (
            <span className="text-xs text-muted-foreground">ETA {formatDuration(eta)}</span>
          )}
        </div>
      </div>
      <div className={cn('w-full rounded-full bg-muted overflow-hidden', size === 'sm' ? 'h-1' : 'h-2')}>
        <div
          className={cn('h-full rounded-full transition-all duration-500', COLOR_CLASSES[color])}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}
