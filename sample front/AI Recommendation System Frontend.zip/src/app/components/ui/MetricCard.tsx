import { motion } from 'motion/react';
import { LucideIcon, TrendingUp, TrendingDown } from 'lucide-react';
import { cn } from '../../lib/utils';

interface MetricCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: LucideIcon;
  trend?: { value: number; label: string };
  color?: 'blue' | 'purple' | 'emerald' | 'amber' | 'red';
  loading?: boolean;
  className?: string;
}

const COLOR_MAP = {
  blue: { bg: 'bg-sky-500/10', icon: 'text-sky-500', ring: 'ring-sky-500/20' },
  purple: { bg: 'bg-violet-500/10', icon: 'text-violet-500', ring: 'ring-violet-500/20' },
  emerald: { bg: 'bg-emerald-500/10', icon: 'text-emerald-500', ring: 'ring-emerald-500/20' },
  amber: { bg: 'bg-amber-500/10', icon: 'text-amber-500', ring: 'ring-amber-500/20' },
  red: { bg: 'bg-red-500/10', icon: 'text-red-500', ring: 'ring-red-500/20' },
};

export function MetricCard({ title, value, subtitle, icon: Icon, trend, color = 'blue', loading, className }: MetricCardProps) {
  const colors = COLOR_MAP[color];

  if (loading) {
    return (
      <div className={cn('bg-card border border-border rounded-xl p-4', className)}>
        <div className="flex items-start justify-between">
          <div className="w-9 h-9 rounded-lg skeleton-shimmer" />
          <div className="w-16 h-5 rounded skeleton-shimmer" />
        </div>
        <div className="mt-4 w-24 h-7 rounded skeleton-shimmer" />
        <div className="mt-1 w-32 h-4 rounded skeleton-shimmer" />
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={cn('bg-card border border-border rounded-xl p-4 hover:border-primary/30 transition-colors', className)}
    >
      <div className="flex items-start justify-between">
        <div className={cn('w-9 h-9 rounded-lg flex items-center justify-center ring-1', colors.bg, colors.ring)}>
          <Icon className={cn('w-4 h-4', colors.icon)} />
        </div>
        {trend && (
          <div className={cn('flex items-center gap-0.5 text-xs font-medium',
            trend.value >= 0 ? 'text-emerald-500' : 'text-red-500'
          )}>
            {trend.value >= 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
            {Math.abs(trend.value)}% {trend.label}
          </div>
        )}
      </div>
      <div className="mt-3">
        <p className="text-2xl font-semibold text-foreground">{value}</p>
        <p className="text-sm text-muted-foreground mt-0.5">{title}</p>
        {subtitle && <p className="text-xs text-muted-foreground/70 mt-1">{subtitle}</p>}
      </div>
    </motion.div>
  );
}
