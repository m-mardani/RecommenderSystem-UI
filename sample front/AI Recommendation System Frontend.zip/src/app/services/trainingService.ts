import apiClient from './api';
import { TrainingJob, TrainingConfig, TrainingProgress, EpochMetrics, PaginatedResponse } from '../types';

export interface CreateTrainingRequest {
  name: string;
  dataset_id: string;
  config: TrainingConfig;
}

export const trainingService = {
  list: (params?: { page?: number; page_size?: number; status?: string }) =>
    apiClient.get<PaginatedResponse<TrainingJob>>('/training', { params }).then(r => r.data),

  get: (id: string) =>
    apiClient.get<TrainingJob>(`/training/${id}`).then(r => r.data),

  create: (data: CreateTrainingRequest) =>
    apiClient.post<TrainingJob>('/training', data).then(r => r.data),

  autoCreate: (dataset_id: string, name: string) =>
    apiClient.post<TrainingJob>('/training/auto', { dataset_id, name }).then(r => r.data),

  getProgress: (id: string) =>
    apiClient.get<TrainingProgress>(`/training/${id}/progress`).then(r => r.data),

  getLogs: (id: string, since?: number) =>
    apiClient.get<string[]>(`/training/${id}/logs`, { params: { since } }).then(r => r.data),

  getEpochMetrics: (id: string) =>
    apiClient.get<EpochMetrics[]>(`/training/${id}/epochs`).then(r => r.data),

  cancel: (id: string) =>
    apiClient.post(`/training/${id}/cancel`).then(r => r.data),

  delete: (id: string) =>
    apiClient.delete(`/training/${id}`).then(r => r.data),
};
