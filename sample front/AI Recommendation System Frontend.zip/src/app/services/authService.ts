import apiClient from './api';
import { LoginRequest, LoginResponse, User } from '../types';

export const authService = {
  login: (data: LoginRequest) =>
    apiClient.post<LoginResponse>('/auth/login', data).then(r => r.data),

  logout: () =>
    apiClient.post('/auth/logout').then(r => r.data),

  me: () =>
    apiClient.get<User>('/auth/me').then(r => r.data),

  refreshToken: (refresh_token: string) =>
    apiClient.post('/auth/refresh', { refresh_token }).then(r => r.data),
};
