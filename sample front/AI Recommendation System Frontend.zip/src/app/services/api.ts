import axios, { AxiosError, AxiosResponse, InternalAxiosRequestConfig } from 'axios';
import { API_V1, ACCESS_TOKEN_KEY, REFRESH_TOKEN_KEY } from '../lib/constants';
import { AuthTokens } from '../types';
import {
  MOCK_USER, MOCK_DATASETS, MOCK_TRAINING_JOBS, MOCK_MODELS,
  MOCK_SNAPSHOT, MOCK_AUDIT_LOGS, MOCK_ONLINE_USERS, MOCK_SYSTEM_LOGS,
  MOCK_DATASET_PREVIEW, MOCK_DATASET_ANALYSIS, MOCK_USERS,
} from './mockData';

export const apiClient = axios.create({
  baseURL: API_V1,
  headers: { 'Content-Type': 'application/json' },
  timeout: 30_000,
});

// ─── Mock adapter ─────────────────────────────────────────────────────────────
const USE_MOCK = true;

function paginate<T>(items: T[], page = 1, page_size = 25) {
  const start = (page - 1) * page_size;
  return {
    items: items.slice(start, start + page_size),
    total: items.length,
    page,
    page_size,
    pages: Math.ceil(items.length / page_size),
  };
}

function mockResponse<T>(data: T, status = 200): AxiosResponse<T> {
  return { data, status, statusText: 'OK', headers: {}, config: {} as InternalAxiosRequestConfig };
}

apiClient.interceptors.request.use(async (config) => {
  const token = localStorage.getItem(ACCESS_TOKEN_KEY);
  if (token && config.headers) {
    config.headers.Authorization = `Bearer ${token}`;
  }

  if (!USE_MOCK) return config;

  const url = config.url ?? '';
  const method = config.method?.toUpperCase() ?? 'GET';
  const params = config.params ?? {};
  const page = Number(params.page ?? 1);
  const page_size = Number(params.page_size ?? 25);
  const search = (params.search ?? '').toLowerCase();

  // Mock responses
  if (url === '/auth/login' && method === 'POST') {
    const body = JSON.parse(config.data ?? '{}');
    if (body.username === 'admin' && body.password === 'admin123') {
      const mockLogin = { ...MOCK_USER, role: 'ADMIN' as const };
      return Promise.reject({ isMockResolved: true, response: mockResponse({ access_token: 'mock-access-token', refresh_token: 'mock-refresh-token', token_type: 'Bearer', expires_in: 3600, user: mockLogin }) });
    }
    if (body.username === 'user' && body.password === 'user123') {
      return Promise.reject({ isMockResolved: true, response: mockResponse({ access_token: 'mock-access-token-user', refresh_token: 'mock-refresh-token-user', token_type: 'Bearer', expires_in: 3600, user: { ...MOCK_USERS[1], role: 'USER' as const } }) });
    }
    return Promise.reject({ isMockResolved: true, error: { response: { status: 401, data: { detail: 'Invalid credentials' } } } });
  }

  if (url === '/auth/me') return Promise.reject({ isMockResolved: true, response: mockResponse(MOCK_USER) });
  if (url === '/auth/logout') return Promise.reject({ isMockResolved: true, response: mockResponse({ ok: true }) });
  if (url === '/auth/refresh') return Promise.reject({ isMockResolved: true, response: mockResponse({ access_token: 'mock-refreshed-token', refresh_token: 'mock-refresh-token', token_type: 'Bearer', expires_in: 3600 }) });

  // Datasets
  if (url === '/datasets' && method === 'GET') {
    const filtered = search ? MOCK_DATASETS.filter(d => d.name.toLowerCase().includes(search)) : MOCK_DATASETS;
    return Promise.reject({ isMockResolved: true, response: mockResponse(paginate(filtered, page, page_size)) });
  }
  if (url.match(/^\/datasets\/[^/]+$/) && method === 'GET') {
    const id = url.split('/')[2];
    const ds = MOCK_DATASETS.find(d => d.id === id);
    return Promise.reject({ isMockResolved: true, response: mockResponse(ds ?? MOCK_DATASETS[0]) });
  }
  if (url.match(/^\/datasets\/[^/]+\/preview$/)) {
    return Promise.reject({ isMockResolved: true, response: mockResponse({ ...MOCK_DATASET_PREVIEW, page, page_size }) });
  }
  if (url.match(/^\/datasets\/[^/]+\/analyze$/)) {
    return Promise.reject({ isMockResolved: true, response: mockResponse(MOCK_DATASET_ANALYSIS) });
  }
  if (url === '/datasets/upload' && method === 'POST') {
    const newDs = { ...MOCK_DATASETS[0], id: `ds-${Date.now()}`, name: 'Uploaded Dataset', status: 'PROCESSING' as const, created_at: new Date().toISOString() };
    return Promise.reject({ isMockResolved: true, response: mockResponse(newDs) });
  }
  if (url.match(/^\/datasets\/[^/]+$/) && method === 'DELETE') {
    return Promise.reject({ isMockResolved: true, response: mockResponse({ ok: true }) });
  }

  // Training
  if (url === '/training' && method === 'GET') {
    const filtered = params.status ? MOCK_TRAINING_JOBS.filter(j => j.status === params.status) : MOCK_TRAINING_JOBS;
    return Promise.reject({ isMockResolved: true, response: mockResponse(paginate(filtered, page, page_size)) });
  }
  if (url.match(/^\/training\/[^/]+$/) && method === 'GET' && !url.endsWith('/progress') && !url.endsWith('/logs') && !url.endsWith('/epochs') && !url.endsWith('/cancel')) {
    const id = url.split('/')[2];
    const job = MOCK_TRAINING_JOBS.find(j => j.id === id);
    return Promise.reject({ isMockResolved: true, response: mockResponse(job ?? MOCK_TRAINING_JOBS[0]) });
  }
  if (url.match(/^\/training\/[^/]+\/progress$/)) {
    const id = url.split('/')[2];
    const job = MOCK_TRAINING_JOBS.find(j => j.id === id) ?? MOCK_TRAINING_JOBS[1];
    return Promise.reject({ isMockResolved: true, response: mockResponse({ job_id: job.id, status: job.status, progress: job.progress, current_epoch: job.current_epoch, total_epochs: job.total_epochs, current_loss: job.current_loss, best_loss: job.best_loss, eta_seconds: job.eta_seconds, logs: MOCK_SYSTEM_LOGS.slice(0, 8) }) });
  }
  if (url.match(/^\/training\/[^/]+\/logs$/)) {
    return Promise.reject({ isMockResolved: true, response: mockResponse(MOCK_SYSTEM_LOGS) });
  }
  if (url.match(/^\/training\/[^/]+\/epochs$/)) {
    const epochs = Array.from({ length: 34 }, (_, i) => ({
      epoch: i + 1, loss: 0.62 - i * 0.008 + Math.random() * 0.01,
      val_loss: 0.65 - i * 0.007 + Math.random() * 0.015, timestamp: daysAgo(i * 0.01),
    }));
    return Promise.reject({ isMockResolved: true, response: mockResponse(epochs) });
  }
  if (url === '/training' && method === 'POST') {
    const body = JSON.parse(config.data ?? '{}');
    const newJob = { ...MOCK_TRAINING_JOBS[0], id: `job-${Date.now()}`, name: body.name ?? 'New Job', status: 'PENDING' as const, progress: 0, current_epoch: 0, created_at: new Date().toISOString() };
    return Promise.reject({ isMockResolved: true, response: mockResponse(newJob) });
  }
  if (url === '/training/auto' && method === 'POST') {
    const body = JSON.parse(config.data ?? '{}');
    const newJob = { ...MOCK_TRAINING_JOBS[0], id: `job-${Date.now()}`, name: body.name ?? 'Auto Job', status: 'PENDING' as const, progress: 0, current_epoch: 0, created_at: new Date().toISOString() };
    return Promise.reject({ isMockResolved: true, response: mockResponse(newJob) });
  }
  if (url.match(/^\/training\/[^/]+\/cancel$/)) {
    return Promise.reject({ isMockResolved: true, response: mockResponse({ ok: true }) });
  }

  // Models
  if (url === '/models' && method === 'GET') {
    const filtered = search ? MOCK_MODELS.filter(m => m.name.toLowerCase().includes(search)) : MOCK_MODELS;
    return Promise.reject({ isMockResolved: true, response: mockResponse(paginate(filtered, page, page_size)) });
  }
  if (url === '/models/available') {
    return Promise.reject({ isMockResolved: true, response: mockResponse(MOCK_MODELS.map(m => ({ id: m.id, name: m.name, strategy: m.strategy, metrics: m.metrics, is_active: m.is_active }))) });
  }
  if (url.match(/^\/models\/[^/]+$/) && method === 'GET') {
    const id = url.split('/')[2];
    const model = MOCK_MODELS.find(m => m.id === id);
    return Promise.reject({ isMockResolved: true, response: mockResponse(model ?? MOCK_MODELS[0]) });
  }
  if (url.match(/^\/models\/[^/]+$/) && method === 'DELETE') {
    return Promise.reject({ isMockResolved: true, response: mockResponse({ ok: true }) });
  }

  // Inference
  if (url === '/inference/recommend') {
    const body = JSON.parse(config.data ?? '{}');
    return Promise.reject({ isMockResolved: true, response: mockResponse({
      user_id: body.user_id,
      model_id: body.model_id,
      recommendations: Array.from({ length: body.top_k ?? 10 }, (_, i) => ({
        item_id: `movie_${1000 + i * 37}`, score: 0.95 - i * 0.04,
        rank: i + 1, explanation: i < 3 ? 'High collaborative similarity' : undefined,
      })),
      inference_time_ms: 18 + Math.random() * 15,
      generated_at: new Date().toISOString(),
    }) });
  }
  if (url === '/inference/predict') {
    const body = JSON.parse(config.data ?? '{}');
    return Promise.reject({ isMockResolved: true, response: mockResponse({
      user_id: body.user_id, item_id: body.item_id,
      score: 0.72 + Math.random() * 0.2, explanation: 'Based on collaborative filtering and content similarity',
      inference_time_ms: 12 + Math.random() * 8,
    }) });
  }
  if (url === '/inference/scenario') {
    const body = JSON.parse(config.data ?? '{}');
    return Promise.reject({ isMockResolved: true, response: mockResponse({
      results: body.scenarios.map((s: { user_id: string; item_id: string }, i: number) => ({
        ...s, score: 0.5 + Math.random() * 0.45, scenario_index: i,
      })),
      total_inference_time_ms: body.scenarios.length * 12,
    }) });
  }

  // Admin
  if (url === '/users' && method === 'GET') {
    const filtered = search ? MOCK_USERS.filter(u => u.username.includes(search) || u.email.includes(search)) : MOCK_USERS;
    return Promise.reject({ isMockResolved: true, response: mockResponse(paginate(filtered, page, page_size)) });
  }
  if (url === '/users' && method === 'POST') {
    const body = JSON.parse(config.data ?? '{}');
    const newUser = { ...MOCK_USERS[0], id: `user-${Date.now()}`, ...body, created_at: new Date().toISOString() };
    return Promise.reject({ isMockResolved: true, response: mockResponse(newUser) });
  }
  if (url.match(/^\/users\/[^/]+$/) && method === 'DELETE') {
    return Promise.reject({ isMockResolved: true, response: mockResponse({ ok: true }) });
  }
  if (url.match(/^\/users\/[^/]+$/) && method === 'PUT') {
    return Promise.reject({ isMockResolved: true, response: mockResponse(MOCK_USER) });
  }
  if (url === '/audit-logs') {
    return Promise.reject({ isMockResolved: true, response: mockResponse(paginate(MOCK_AUDIT_LOGS, page, page_size)) });
  }
  if (url === '/monitoring/online-users') {
    return Promise.reject({ isMockResolved: true, response: mockResponse(MOCK_ONLINE_USERS) });
  }

  // Monitoring
  if (url === '/system/snapshot') {
    return Promise.reject({ isMockResolved: true, response: mockResponse(MOCK_SNAPSHOT) });
  }
  if (url === '/monitoring/metrics') {
    return Promise.reject({ isMockResolved: true, response: mockResponse(MOCK_SNAPSHOT.metrics) });
  }
  if (url === '/monitoring/jobs') {
    return Promise.reject({ isMockResolved: true, response: mockResponse(MOCK_TRAINING_JOBS.filter(j => j.status === 'RUNNING' || j.status === 'PENDING')) });
  }
  if (url === '/monitoring/uploads') {
    return Promise.reject({ isMockResolved: true, response: mockResponse([]) });
  }
  if (url === '/monitoring/queue') {
    return Promise.reject({ isMockResolved: true, response: mockResponse({ pending: 1, running: 1, completed_today: 7, failed_today: 1, avg_wait_time_seconds: 120 }) });
  }
  if (url === '/monitoring/logs') {
    return Promise.reject({ isMockResolved: true, response: mockResponse(MOCK_SYSTEM_LOGS) });
  }

  // Auth misc
  if (url === '/auth/change-password') {
    return Promise.reject({ isMockResolved: true, response: mockResponse({ ok: true }) });
  }

  return config;
});

function daysAgo(d: number) {
  return new Date(Date.now() - d * 86400000).toISOString();
}

// ─── Response interceptors ─────────────────────────────────────────────────────
let isRefreshing = false;
let failedQueue: { resolve: (v: string) => void; reject: (e: unknown) => void }[] = [];

function processQueue(error: unknown, token: string | null) {
  failedQueue.forEach(({ resolve, reject }) => {
    if (error) reject(error);
    else if (token) resolve(token);
  });
  failedQueue = [];
}

apiClient.interceptors.response.use(
  (response) => response,
  async (error: AxiosError & { isMockResolved?: boolean; response?: AxiosResponse }) => {
    // Handle mock resolved responses
    if (error.isMockResolved) {
      if ((error as { error?: unknown }).error) {
        const mockError = (error as { error: AxiosError }).error;
        return Promise.reject(mockError);
      }
      return Promise.resolve(error.response!);
    }

    const original = error.config as InternalAxiosRequestConfig & { _retry?: boolean };
    if (error.response?.status === 401 && !original?._retry) {
      const refreshToken = localStorage.getItem(REFRESH_TOKEN_KEY);
      if (!refreshToken) {
        window.dispatchEvent(new CustomEvent('auth:logout'));
        return Promise.reject(error);
      }
      if (isRefreshing) {
        return new Promise<string>((resolve, reject) => {
          failedQueue.push({ resolve, reject });
        }).then((token) => {
          original.headers!.Authorization = `Bearer ${token}`;
          return apiClient(original);
        });
      }
      original._retry = true;
      isRefreshing = true;
      try {
        const { data } = await axios.post<AuthTokens>(`${API_V1}/auth/refresh`, {
          refresh_token: refreshToken,
        });
        localStorage.setItem(ACCESS_TOKEN_KEY, data.access_token);
        localStorage.setItem(REFRESH_TOKEN_KEY, data.refresh_token);
        apiClient.defaults.headers.common.Authorization = `Bearer ${data.access_token}`;
        processQueue(null, data.access_token);
        original.headers!.Authorization = `Bearer ${data.access_token}`;
        return apiClient(original);
      } catch (refreshError) {
        processQueue(refreshError, null);
        window.dispatchEvent(new CustomEvent('auth:logout'));
        return Promise.reject(refreshError);
      } finally {
        isRefreshing = false;
      }
    }
    return Promise.reject(error);
  }
);

export default apiClient;
