import apiClient from './api';
import { Model, AvailableModel, PaginatedResponse } from '../types';

export const modelService = {
  list: (params?: { page?: number; page_size?: number; search?: string; strategy?: string }) =>
    apiClient.get<PaginatedResponse<Model>>('/models', { params }).then(r => r.data),

  get: (id: string) =>
    apiClient.get<Model>(`/models/${id}`).then(r => r.data),

  available: () =>
    apiClient.get<AvailableModel[]>('/models/available').then(r => r.data),

  delete: (id: string) =>
    apiClient.delete(`/models/${id}`).then(r => r.data),

  activate: (id: string) =>
    apiClient.post(`/models/${id}/activate`).then(r => r.data),
};
