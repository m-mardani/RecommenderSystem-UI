import apiClient from './api';
import { SystemMetrics, SystemSnapshot, QueueStatus, UploadStatus, TrainingJob } from '../types';

export const monitoringService = {
  snapshot: () =>
    apiClient.get<SystemSnapshot>('/system/snapshot').then(r => r.data),

  metrics: () =>
    apiClient.get<SystemMetrics>('/monitoring/metrics').then(r => r.data),

  runningJobs: () =>
    apiClient.get<TrainingJob[]>('/monitoring/jobs').then(r => r.data),

  uploads: () =>
    apiClient.get<UploadStatus[]>('/monitoring/uploads').then(r => r.data),

  queue: () =>
    apiClient.get<QueueStatus>('/monitoring/queue').then(r => r.data),

  logs: (lines = 100) =>
    apiClient.get<string[]>('/monitoring/logs', { params: { lines } }).then(r => r.data),
};
