import { User, Dataset, TrainingJob, Model, SystemSnapshot, AuditLog, OnlineUser } from '../types';

const now = new Date().toISOString();
const daysAgo = (d: number) => new Date(Date.now() - d * 86400000).toISOString();

export const MOCK_USER: User = {
  id: 'user-1',
  username: 'admin',
  email: 'admin@airec.io',
  full_name: 'Alex Chen',
  role: 'ADMIN',
  is_active: true,
  created_at: daysAgo(180),
  last_login: daysAgo(0),
};

export const MOCK_DATASETS: Dataset[] = [
  { id: 'ds-1', name: 'MovieLens 1M', description: 'Classic movie ratings dataset', filename: 'movielens-1m.csv', file_size: 24117945, row_count: 1000209, column_count: 4, status: 'READY', created_at: daysAgo(30), updated_at: daysAgo(5), created_by: 'admin', tags: ['movies', 'ratings'] },
  { id: 'ds-2', name: 'Amazon Reviews Electronics', description: 'Product reviews for electronics', filename: 'amazon-elec.csv', file_size: 156349012, row_count: 4894981, column_count: 6, status: 'READY', created_at: daysAgo(20), updated_at: daysAgo(3), created_by: 'admin', tags: ['amazon', 'ecommerce'] },
  { id: 'ds-3', name: 'Netflix Prize Subset', description: 'Netflix prize data sample', filename: 'netflix-subset.csv', file_size: 45234512, row_count: 500000, column_count: 4, status: 'READY', created_at: daysAgo(15), updated_at: daysAgo(1), created_by: 'user1', tags: ['streaming', 'ratings'] },
  { id: 'ds-4', name: 'Spotify Listening History', description: 'Music listening session data', filename: 'spotify-sessions.csv', file_size: 89012345, row_count: 2000000, column_count: 8, status: 'PROCESSING', created_at: daysAgo(2), updated_at: daysAgo(0), created_by: 'admin', tags: ['music', 'sessions'] },
  { id: 'ds-5', name: 'BookCrossing Dataset', description: 'Book ratings from crossings', filename: 'bookcrossing.csv', file_size: 12034512, row_count: 340000, column_count: 3, status: 'READY', created_at: daysAgo(45), updated_at: daysAgo(10), created_by: 'user2' },
];

export const MOCK_TRAINING_JOBS: TrainingJob[] = [
  { id: 'job-1', name: 'MovieLens CF v3', dataset_id: 'ds-1', dataset_name: 'MovieLens 1M', config: { strategy: 'collaborative_filtering', epochs: 100, learning_rate: 0.001, batch_size: 512, auto_configure: false }, status: 'COMPLETED', progress: 100, current_epoch: 100, total_epochs: 100, current_loss: 0.2341, best_loss: 0.2188, started_at: daysAgo(7), completed_at: daysAgo(6), created_at: daysAgo(7), created_by: 'admin', model_id: 'model-1' },
  { id: 'job-2', name: 'Amazon Hybrid Rec', dataset_id: 'ds-2', dataset_name: 'Amazon Reviews', config: { strategy: 'hybrid', epochs: 50, learning_rate: 0.0005, batch_size: 256, auto_configure: true }, status: 'RUNNING', progress: 68, current_epoch: 34, total_epochs: 50, current_loss: 0.3812, best_loss: 0.3601, eta_seconds: 2400, started_at: daysAgo(0), created_at: daysAgo(0), created_by: 'admin' },
  { id: 'job-3', name: 'Netflix Neural Net', dataset_id: 'ds-3', dataset_name: 'Netflix Prize Subset', config: { strategy: 'neural', epochs: 200, learning_rate: 0.0003, batch_size: 1024, auto_configure: false }, status: 'PENDING', progress: 0, current_epoch: 0, total_epochs: 200, created_at: daysAgo(0), created_by: 'admin' },
  { id: 'job-4', name: 'BookCrossing Content', dataset_id: 'ds-5', dataset_name: 'BookCrossing', config: { strategy: 'content_based', epochs: 30, learning_rate: 0.001, batch_size: 256, auto_configure: false }, status: 'FAILED', progress: 23, current_epoch: 7, total_epochs: 30, error_message: 'CUDA out of memory', started_at: daysAgo(3), created_at: daysAgo(3), created_by: 'user1' },
];

export const MOCK_MODELS: Model[] = [
  { id: 'model-1', name: 'MovieLens CF v3', strategy: 'collaborative_filtering', version: '3.0.0', metrics: { precision: 0.8234, recall: 0.7891, f1_score: 0.8059, ndcg: 0.8512, map: 0.7743 }, training_job_id: 'job-1', dataset_id: 'ds-1', dataset_name: 'MovieLens 1M', file_size_mb: 234.5, is_active: true, created_at: daysAgo(6), created_by: 'admin', tags: ['production', 'movies'] },
  { id: 'model-2', name: 'Amazon Hybrid v1', strategy: 'hybrid', version: '1.0.0', metrics: { precision: 0.7891, recall: 0.8234, f1_score: 0.8059, ndcg: 0.7913, map: 0.7512 }, training_job_id: 'job-2', dataset_id: 'ds-2', dataset_name: 'Amazon Reviews', file_size_mb: 456.2, is_active: false, created_at: daysAgo(14), created_by: 'admin', tags: ['ecommerce'] },
  { id: 'model-3', name: 'BookCrossing Content v2', strategy: 'content_based', version: '2.1.0', metrics: { precision: 0.7123, recall: 0.6892, f1_score: 0.7006, ndcg: 0.7234 }, training_job_id: 'job-4', dataset_id: 'ds-5', dataset_name: 'BookCrossing', file_size_mb: 89.3, is_active: false, created_at: daysAgo(30), created_by: 'user1', tags: ['books'] },
];

export const MOCK_SNAPSHOT: SystemSnapshot = {
  metrics: { cpu_percent: 34.2, memory_percent: 58.7, memory_used_gb: 9.4, memory_total_gb: 16, disk_percent: 42.1, disk_used_gb: 210.5, disk_total_gb: 500, gpu_percent: 67, network_rx_mbps: 12.3, network_tx_mbps: 4.5, timestamp: now },
  active_jobs: 1, pending_jobs: 1, total_models: 3, total_datasets: 5, online_users: 3, uptime_seconds: 864000,
};

export const MOCK_AUDIT_LOGS: AuditLog[] = [
  { id: 'log-1', user_id: 'user-1', username: 'admin', action: 'LOGIN', resource_type: 'auth', timestamp: daysAgo(0), success: true, ip_address: '192.168.1.100' },
  { id: 'log-2', user_id: 'user-1', username: 'admin', action: 'DATASET_UPLOAD', resource_type: 'dataset', resource_id: 'ds-4', timestamp: daysAgo(2), success: true, ip_address: '192.168.1.100' },
  { id: 'log-3', user_id: 'user-1', username: 'admin', action: 'TRAINING_START', resource_type: 'training_job', resource_id: 'job-2', timestamp: daysAgo(0), success: true, ip_address: '192.168.1.100' },
  { id: 'log-4', user_id: 'user-2', username: 'user1', action: 'LOGIN', resource_type: 'auth', timestamp: daysAgo(1), success: false, ip_address: '10.0.0.45' },
  { id: 'log-5', user_id: 'user-2', username: 'user1', action: 'MODEL_DELETE', resource_type: 'model', resource_id: 'model-3', timestamp: daysAgo(1), success: true, ip_address: '10.0.0.45' },
];

export const MOCK_ONLINE_USERS: OnlineUser[] = [
  { user_id: 'user-1', username: 'admin', role: 'ADMIN', connected_at: daysAgo(0), last_activity: now, ip_address: '192.168.1.100' },
  { user_id: 'user-2', username: 'user1', role: 'USER', connected_at: new Date(Date.now() - 3600000).toISOString(), last_activity: new Date(Date.now() - 600000).toISOString(), ip_address: '10.0.0.45' },
  { user_id: 'user-3', username: 'mleng2', role: 'USER', connected_at: new Date(Date.now() - 1800000).toISOString(), last_activity: new Date(Date.now() - 120000).toISOString(), ip_address: '172.16.0.22' },
];

export const MOCK_SYSTEM_LOGS = [
  '[2026-08-01 12:00:01] INFO  Server started on port 8000',
  '[2026-08-01 12:00:02] INFO  Database connection established',
  '[2026-08-01 12:00:03] INFO  Redis cache connected',
  '[2026-08-01 12:00:15] INFO  Training job job-2 started',
  '[2026-08-01 12:00:16] INFO  Loading dataset ds-2 (4.89M rows)',
  '[2026-08-01 12:00:45] INFO  Epoch 1/50 - loss: 0.6234, val_loss: 0.6489',
  '[2026-08-01 12:01:23] INFO  Epoch 5/50 - loss: 0.4892, val_loss: 0.5103',
  '[2026-08-01 12:02:11] INFO  Epoch 10/50 - loss: 0.4123, val_loss: 0.4456',
  '[2026-08-01 12:03:45] INFO  Epoch 20/50 - loss: 0.3921, val_loss: 0.4189',
  '[2026-08-01 12:05:22] INFO  Epoch 34/50 - loss: 0.3812, val_loss: 0.3946 (best)',
  '[2026-08-01 12:06:01] WARN  High memory usage detected: 87%',
  '[2026-08-01 12:06:02] INFO  Memory pressure managed by evicting LRU cache entries',
  '[2026-08-01 12:07:15] INFO  User admin uploaded dataset ds-4',
  '[2026-08-01 12:08:30] INFO  User user1 requested inference on model-1',
  '[2026-08-01 12:09:45] INFO  Recommendation generated in 23ms',
  '[2026-08-01 12:10:00] INFO  Periodic health check passed',
];

export const MOCK_DATASET_PREVIEW = {
  columns: ['user_id', 'item_id', 'rating', 'timestamp'],
  rows: Array.from({ length: 50 }, (_, i) => ({
    user_id: `user_${Math.floor(Math.random() * 6040) + 1}`,
    item_id: `movie_${Math.floor(Math.random() * 3706) + 1}`,
    rating: (Math.floor(Math.random() * 5) + 1).toString(),
    timestamp: Math.floor(Date.now() / 1000 - Math.random() * 3e8).toString(),
  })),
  total_rows: 1000209,
  page: 1,
  page_size: 50,
};

export const MOCK_DATASET_ANALYSIS = {
  dataset_id: 'ds-1',
  row_count: 1000209,
  column_count: 4,
  columns: [
    { name: 'user_id', dtype: 'int64', null_count: 0, unique_count: 6040, min: 1, max: 6040 },
    { name: 'item_id', dtype: 'int64', null_count: 0, unique_count: 3706, min: 1, max: 3952 },
    { name: 'rating', dtype: 'float32', null_count: 0, unique_count: 5, min: 1, max: 5, mean: 3.58, std: 1.12 },
    { name: 'timestamp', dtype: 'int64', null_count: 0, unique_count: 458455, min: 789652009, max: 1076454980 },
  ],
  missing_percentage: 0,
  memory_usage_mb: 30.5,
  analyzed_at: daysAgo(5),
};

export const MOCK_USERS: User[] = [
  MOCK_USER,
  { id: 'user-2', username: 'user1', email: 'user1@airec.io', full_name: 'Sarah Johnson', role: 'USER', is_active: true, created_at: daysAgo(120), last_login: daysAgo(1) },
  { id: 'user-3', username: 'mleng2', email: 'mleng2@airec.io', full_name: 'David Kim', role: 'USER', is_active: true, created_at: daysAgo(90), last_login: daysAgo(0) },
  { id: 'user-4', username: 'readonly', email: 'readonly@airec.io', full_name: 'Emma Davis', role: 'USER', is_active: false, created_at: daysAgo(200), last_login: daysAgo(30) },
];
