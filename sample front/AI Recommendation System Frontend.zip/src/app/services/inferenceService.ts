import apiClient from './api';
import {
  RecommendationRequest, RecommendationResponse,
  PredictionRequest, PredictionResponse,
  ScenarioRequest, ScenarioResponse,
} from '../types';

export const inferenceService = {
  recommend: (data: RecommendationRequest) =>
    apiClient.post<RecommendationResponse>('/inference/recommend', data).then(r => r.data),

  predict: (data: PredictionRequest) =>
    apiClient.post<PredictionResponse>('/inference/predict', data).then(r => r.data),

  scenario: (data: ScenarioRequest) =>
    apiClient.post<ScenarioResponse>('/inference/scenario', data).then(r => r.data),
};
