import apiClient from './api';
import { User, CreateUserRequest, AuditLog, OnlineUser, PaginatedResponse } from '../types';

export const adminService = {
  listUsers: (params?: { page?: number; page_size?: number; search?: string; role?: string }) =>
    apiClient.get<PaginatedResponse<User>>('/users', { params }).then(r => r.data),

  createUser: (data: CreateUserRequest) =>
    apiClient.post<User>('/users', data).then(r => r.data),

  updateUser: (id: string, data: Partial<User>) =>
    apiClient.put<User>(`/users/${id}`, data).then(r => r.data),

  deleteUser: (id: string) =>
    apiClient.delete(`/users/${id}`).then(r => r.data),

  getUser: (id: string) =>
    apiClient.get<User>(`/users/${id}`).then(r => r.data),

  auditLogs: (params?: { page?: number; page_size?: number; user_id?: string; action?: string }) =>
    apiClient.get<PaginatedResponse<AuditLog>>('/audit-logs', { params }).then(r => r.data),

  onlineUsers: () =>
    apiClient.get<OnlineUser[]>('/monitoring/online-users').then(r => r.data),
};
