import apiClient from './api';
import { Dataset, DatasetPreview, DatasetAnalysis, PaginatedResponse } from '../types';

export const datasetService = {
  list: (params?: { page?: number; page_size?: number; search?: string; status?: string }) =>
    apiClient.get<PaginatedResponse<Dataset>>('/datasets', { params }).then(r => r.data),

  get: (id: string) =>
    apiClient.get<Dataset>(`/datasets/${id}`).then(r => r.data),

  upload: (file: File, name: string, description?: string, onProgress?: (p: number) => void) => {
    const form = new FormData();
    form.append('file', file);
    form.append('name', name);
    if (description) form.append('description', description);
    return apiClient.post<Dataset>('/datasets/upload', form, {
      headers: { 'Content-Type': 'multipart/form-data' },
      onUploadProgress: (e) => {
        if (onProgress && e.total) onProgress(Math.round((e.loaded * 100) / e.total));
      },
    }).then(r => r.data);
  },

  delete: (id: string) =>
    apiClient.delete(`/datasets/${id}`).then(r => r.data),

  preview: (id: string, page = 1, page_size = 50) =>
    apiClient.get<DatasetPreview>(`/datasets/${id}/preview`, { params: { page, page_size } }).then(r => r.data),

  analyze: (id: string) =>
    apiClient.get<DatasetAnalysis>(`/datasets/${id}/analyze`).then(r => r.data),
};
