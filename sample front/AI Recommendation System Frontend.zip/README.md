
  # AI Recommendation System Frontend

  This is a code bundle for AI Recommendation System Frontend. The original project is available at https://www.figma.com/design/ImiA9ITxc1wf0ZrR9ReUyC/AI-Recommendation-System-Frontend.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  